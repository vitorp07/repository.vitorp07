import datetime
import xbmc
import settings
from default import update_library
from resources.lib import video_player
from resources.lib import meta_players
from resources.lib.xswift2 import plugin

def go_idle(duration):
    while not xbmc.abortRequested and duration > 0:
        PLAYER = video_player.VideoPlayer()
        if PLAYER.isPlayingVideo(): PLAYER.currentTime = PLAYER.getTime()
        xbmc.sleep(1000)
        duration -= 1

def future(seconds):
    return datetime.datetime.now() + datetime.timedelta(seconds=seconds)

def main():
    go_idle(10)
    if plugin.get_setting(settings.SETTING_TOTAL_SETUP_DONE, bool) == False:
        xbmc.executebuiltin('RunPlugin(plugin://script.meta/setup/total)')
        plugin.set_setting(settings.SETTING_TOTAL_SETUP_DONE, 'true')
    meta_players.patch('auto')
    next_update = future(0)
    while not xbmc.abortRequested:
        if next_update <= future(0):
            next_update = future(plugin.get_setting(settings.SETTING_UPDATE_LIBRARY_INTERVAL, int) * 60 * 60)
            update_library()
        go_idle(30*60)

if __name__ == '__main__': main()