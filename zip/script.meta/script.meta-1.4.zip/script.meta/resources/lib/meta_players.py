import json
import xbmc, xbmcvfs, xbmcaddon
import settings
from resources.lib import dialogs
from resources.lib.xswift2 import plugin

class AddonPlayer(object):
    def __init__(self, filename, media, meta):
        self.media = media
        self.title = meta["name"]
        self.repoid = meta.get("repository")
        self.pluginid = meta.get("plugin")
        self.id = meta.get("id", filename.replace(".json", ""))
        self.order = meta.get("priority")
        self.commands = meta.get(media, [])

    def is_empty(self):
        if self.pluginid and not xbmc.getCondVisibility('System.HasAddon(%s)' %self.pluginid): return True
        return not bool(self.commands)

def get_players(media):
    assert media in ("tvshows", "movies")
    players = []
    players_path = "special://profile/addon_data/script.meta/Players/"
    files = [x for x in xbmcvfs.listdir(players_path)[1] if x.endswith(".json")]
    for file in files:
        path = players_path + file
        f = xbmcvfs.File(path)
        content = f.read()
        meta = json.loads(content)
        f.close()
        player = AddonPlayer(file, media, meta)
        if not player.is_empty(): players.append(player)
    return sort_players(players)

def sort_players(players):
    result = []
    for player in players: result.append((player.order, player))
    result.sort()
    return [x[-1] for x in result]

def get_needed_langs(players):
    languages = set()
    for player in players:
        for command_group in player.commands:  
            for command in command_group:
                command_lang = command.get("language", "en")
                languages.add(command_lang)
    return languages

ADDON_SELECTOR = AddonPlayer("selector", "any", meta={"name": "Selector"})

@plugin.route('/patch/<mode>', options = {"mode": "all"})
def patch(mode):
    adir = "special://home/addons/"
    AUTOS = eval(plugin.get_setting(settings.SETTING_AUTOPATCHES, unicode))
    INSTALLED = [i for i in xbmcvfs.listdir(adir)[0]]
    PATCHES = [[], ["resources/lib/modules/control.py", "pass", "sys.exit()"], ["default.py", "", "\n    cool_down_active = kodi.get_setting('cool_down') == 'true'\n    if not salts_utils.is_salts() or cool_down_active:\n        kodi.notify(msg=i18n('playback_limited'))\n        return False"], ["lib/dudehere/routines/scrapers/__init__.py", "", "\n\t\tif self._caller not in ALLOWED_CALLERS and self._caller: \n\t\t\tplugin.log('Caller not allowed')\n\t\t\tplugin.raise_error('Violation', 'This addon is not allowed.', 'Please do not use %s with %s' %(self._caller, ADDON_NAME))\n\t\t\tif return_sources:\n\t\t\t\treturn [], [], []\n\t\t\telse:\n\t\t\t\treturn []"]]
    if mode == "auto":
        if AUTOS != [[], [], [], []]: ADDONS = AUTOS
        else:
            message = "Auto-patches not found"
            if dialogs.yesno('%s: Patch' %(plugin.name), '%s.[CR]%s & %s' %(message, "Enable", "Continue?")): return patch("all")
            else: return
    else: ADDONS = [[], [i for i in INSTALLED if (i.startswith("plugin.video.") and xbmcvfs.exists("%s%s/%s" %(adir, i, PATCHES[1][0]))) or (i.startswith("script.module.") and xbmcvfs.exists("%s%s/lib/%s" %(adir, i, PATCHES[1][0])))], [i for i in INSTALLED if i.startswith("plugin.video.") and xbmcvfs.exists("%s%s/%s" %(adir, i, PATCHES[2][0]))], [i for i in INSTALLED if i.startswith("script.module.") and xbmcvfs.exists("%s%s/%s" %(adir, i, PATCHES[3][0]))]]
    count = 0
    for i in range(1, len(ADDONS)):
        for a in ADDONS[i]:
            count = count + 1
            b = "%s%s/%s" %(adir, a, PATCHES[i][0]) if xbmcvfs.exists("%s%s/%s" %(adir, a, PATCHES[i][0])) else "%s%s/lib/%s" %(adir, a, PATCHES[i][0])
            c = xbmcvfs.File(b)
            d = c.read()
            c.close()
            if PATCHES[i][2] in d:
                ADDON = xbmcaddon.Addon(a)
                if mode == "auto" or dialogs.yesno('Patch: %s?' %s(plugin.name, ADDON.getAddonInfo("name")),'%s contains block-code against external add-ons.[CR]To use it via context player Meta will try to patch the block-code.' %(plugin.name, ADDON.getAddonInfo("name"))):
                    h = xbmcvfs.File(b, 'w')
                    d = d.replace(PATCHES[i][2], PATCHES[i][1])
                    result = h.write(d)
                    h.close()
                    if mode != "auto" and dialogs.yesno('Auto patch: %s?' %(plugin.name, ADDON.getAddonInfo("name")),'Select Yes to re-patch %s whenever needed.' %(plugin.name, ADDON.getAddonInfo("name"))):
                        if ADDON.getAddonInfo("id") not in AUTOS[i]: AUTOS[i].append(ADDON.getAddonInfo("id"))
    if AUTOS != [[], [], [], []] and AUTOS != ADDONS: plugin.set_setting(settings.SETTING_AUTOPATCHES, AUTOS)