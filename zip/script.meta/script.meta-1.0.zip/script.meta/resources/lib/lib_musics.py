import os, re, shutil, requests
import xbmc, xbmcvfs
import settings
from resources import plugin
from resources.lib import dialogs
from resources.lib.text import to_utf8
from resources.lib import tools
from resources.lib import nav_base
from resources.lib import Last_fm

def update_library():
    library_folder = plugin.get_setting(settings.SETTING_MUSIC_LIBRARY_FOLDER, unicode)
    if not xbmcvfs.exists(library_folder): return
    tools.scan_library(type="music")

def add_music_to_library(library_folder, artist_name, album_name, track_name):
    safe_artist_name = to_utf8(re.sub("[\\\\<>:\"|?*/]", "_", artist_name))
    safe_album_name = to_utf8(re.sub("[\\\\<>:\"|?*/]", "_", album_name))
    safe_track_name = to_utf8(re.sub("[\\\\<>:\"|?*/]", "_", track_name))
    changed = False
    artist_info = Last_fm.get_artist_info(artist_name)
    album_info = Last_fm.get_album_info(artist_name, album_name)
    artist_folder = os.path.join(library_folder, safe_artist_name)
    album_folder = os.path.join(artist_folder, safe_album_name)
    if not xbmcvfs.exists(artist_folder): xbmcvfs.mkdir(artist_folder)
    if not xbmcvfs.exists(album_folder): xbmcvfs.mkdir(album_folder)
    nfo_artist_path = os.path.join(artist_folder, "artist.nfo")
    nfo_album_path = os.path.join(album_folder, "album.nfo")
    track_info = Last_fm.get_track_info(artist_name, track_name)
    track_number = ""
    if "album" in track_info:
        try: track_number = track_info["album"]["@attr"]["position"]
        except:
            track_number = ""
        if track_number != "" and track_number != None: full_track_name = track_number + ". " + safe_track_name
        else: full_track_name = safe_track_name
    else: full_track_name = safe_track_name
    nfo_track_path = os.path.join(album_folder, full_track_name + ".nfo")
    if not xbmcvfs.exists(nfo_artist_path):
        changed = True
        image = artist_info["image"][-1]["#text"]
        nfo_file = xbmcvfs.File(nfo_artist_path, 'w')
        content = "<artist>\n" \
                  "  <name>%s</name>\n" \
                  "  <thumb>%s</thumb>\n" \
                  "</artist>" %(artist_name, image)
        nfo_file.write(content)
        nfo_file.close()
    if not xbmcvfs.exists(nfo_album_path):
        changed = True
        image = album_info["image"][-1]["#text"]
        nfo_file = xbmcvfs.File(nfo_album_path, 'w')
        content = "<album>\n" \
                  "  <title>%s</title>\n" \
                  "  <artist>%s</artist>\n" \
                  "  <thumb>%s</thumb>\n" \
                  "</album>" %(album_name, artist_name, image)
        nfo_file.write(content)
        nfo_file.close()
    if not xbmcvfs.exists(nfo_track_path):
        changed = True
        track_info = Last_fm.get_track_info(artist_name, track_name)
        track_number = ""
        if "album" in track_info:
            try: track_number = track_info["album"]["@attr"]["position"]
            except: track_number = ""
        else: track_number = ""
        nfo_file = xbmcvfs.File(nfo_track_path, 'w')
        content = "<song>\n" \
                  "  <title>%s</title>\n" \
                  "  <artist>%s</artist>\n" \
                  "  <album>%s</album>\n" \
                  "  <track>%s</track>\n" \
                  "</song>" %(to_utf8(track_name), artist_name, album_name, track_number)
        nfo_file.write(content)
        nfo_file.close()
    strm_filepath = os.path.join(album_folder, full_track_name + ".strm")
    if not xbmcvfs.exists(strm_filepath):
        changed = True
        track_info = Last_fm.get_track_info(artist_name, track_name)
        strm_filepath = os.path.join(album_folder, full_track_name + ".strm")
        strm_file = xbmcvfs.File(strm_filepath, 'w')
        content = plugin.url_for("music_play", artist_name=artist_name, track_name=track_name, album_name=album_name, mode="context")
        strm_file.write(content)
        strm_file.close()
    thumb_album_path = os.path.join(artist_folder, "folder.jpg")
    if not xbmcvfs.exists(thumb_album_path):
            changed = True
            r = requests.get(artist_info["image"][-1]["#text"], stream=True)
            if r.status_code == 200:
                try:
                    with open(thumb_album_path, 'wb') as f:
                        r.raw.decode_content = True
                        shutil.copyfileobj(r.raw, f)
                except: pass
    thumb_album_path = os.path.join(album_folder, "folder.jpg")
    if not xbmcvfs.exists(thumb_album_path):
            changed = True
            try:
                r = requests.get(album_info["image"][-1]["#text"], stream=True)
                if r.status_code == 200:
                    with open(thumb_album_path, 'wb') as f:
                        r.raw.decode_content = True
                        shutil.copyfileobj(r.raw, f)
            except: pass
    return changed

def setup_library(library_folder):
    if library_folder[-1] != "/" and library_folder[-1] != "\\":
        library_folder += "/"
    if not xbmcvfs.exists(library_folder):
        xbmcvfs.mkdir(library_folder)
        msg = "Would you like to automatically set Meta as a music source?"
        if dialogs.yesno("Library setup", msg):
            source_thumbnail = nav_base.get_icon_path("music")
            source_name = "Meta Music"
            source_content = "('%s','music','','',2147483647,0,'',0,0,NULL,NULL)" %library_folder
            tools.add_source(source_name, library_folder, source_content, source_thumbnail, type='music')
    return xbmc.translatePath(library_folder)

def auto_music_setup(library_folder):
    if library_folder[-1] != "/" and library_folder[-1] != "\\":
        library_folder += "/"
    if not xbmcvfs.exists(library_folder):
        try:
            xbmcvfs.mkdir(library_folder)
            source_thumbnail = nav_base.get_icon_path("music")
            source_name = "Meta Music"
            source_content = "('%s','music','','',2147483647,0,'',0,0,NULL,NULL)" %library_folder
            tools.add_source(source_name, library_folder, source_content, source_thumbnail, type='music')
            return True
        except: False