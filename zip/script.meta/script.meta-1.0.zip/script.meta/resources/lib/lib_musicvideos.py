import os, re, shutil, requests
import xbmc, xbmcvfs
import settings
from resources import plugin
from resources.lib import dialogs
from resources.lib.text import to_utf8
from resources.lib import tools
from resources.lib import nav_base
from resources.lib import Last_fm

def update_library():
    library_folder = plugin.get_setting(settings.SETTING_MUSICVIDEOS_LIBRARY_FOLDER, unicode)
    if not xbmcvfs.exists(library_folder): return
    tools.scan_library(type="video")

def add_musicvideos_to_library(library_folder, artist_name, album_name, track_name):
    safe_artist_name = to_utf8(re.sub("[^\w\-_\. '()]", "_", artist_name))
    safe_album_name = to_utf8(re.sub("[^\w\-_\. '()]", "_", album_name))
    safe_track_name = to_utf8(re.sub("[^\w\-_\. '()]", "_", track_name))
    changed = False
    artist_info = Last_fm.get_artist_info(artist_name)
    album_info = Last_fm.get_album_info(artist_name, album_name)
    artist_folder = os.path.join(library_folder, safe_artist_name)
    album_folder = os.path.join(artist_folder, safe_album_name)
    if not xbmcvfs.exists(artist_folder): xbmcvfs.mkdir(artist_folder)
    if not xbmcvfs.exists(album_folder): xbmcvfs.mkdir(album_folder)
    nfo_artist_path = os.path.join(artist_folder, "artist.nfo")
    nfo_album_path = os.path.join(album_folder, "album.nfo")
    track_info = Last_fm.get_track_info(artist_name, track_name)
    full_track_name = safe_artist_name + " - " + safe_track_name
    nfo_track_path = os.path.join(album_folder, full_track_name + ".nfo")
    if not xbmcvfs.exists(nfo_artist_path):
        changed = True
        image = artist_info["image"][-1]["#text"]
        nfo_file = xbmcvfs.File(nfo_artist_path, 'w')
        content = "<artist>\n" \
                  "  <name>%s</name>\n" \
                  "  <thumb>%s</thumb>\n" \
                  "</artist>" %(artist_name, image)
        nfo_file.write(content)
        nfo_file.close()
    if not xbmcvfs.exists(nfo_album_path):
        changed = True
        image = album_info["image"][-1]["#text"]
        nfo_file = xbmcvfs.File(nfo_album_path, 'w')
        content = "<album>\n" \
                  "  <title>%s</title>\n" \
                  "  <artist>%s</artist>\n" \
                  "  <thumb>%s</thumb>\n" \
                  "</album>" %(album_name, artist_name, image)
        nfo_file.write(content)
        nfo_file.close()
    strm_filepath = os.path.join(album_folder, full_track_name + ".strm")
    if not xbmcvfs.exists(strm_filepath):
        changed = True
        track_info = Last_fm.get_track_info(artist_name, track_name)
        if "album" in track_info: strm_filepath = os.path.join(album_folder, full_track_name + ".strm")
        strm_file = xbmcvfs.File(strm_filepath, 'w')
        content = plugin.url_for("musicvideos_play", artist_name=artist_name, track_name=track_name, album_name=album_name, mode="context")
        strm_file.write(content)
        strm_file.close()
    thumb_album_path = os.path.join(artist_folder, "folder.jpg")
    if not xbmcvfs.exists(thumb_album_path):
            changed = True
            r = requests.get(artist_info["image"][-1]["#text"], stream=True)
            if r.status_code == 200:
                try:
                    with open(thumb_album_path, 'wb') as f:
                        r.raw.decode_content = True
                        shutil.copyfileobj(r.raw, f)
                except: pass
    thumb_album_path = os.path.join(album_folder, "folder.jpg")
    if not xbmcvfs.exists(thumb_album_path):
            changed = True
            try:
                r = requests.get(album_info["image"][-1]["#text"], stream=True)
                if r.status_code == 200:
                    with open(thumb_album_path, 'wb') as f:
                        r.raw.decode_content = True
                        shutil.copyfileobj(r.raw, f)
            except: pass
    return changed

def setup_library(library_folder):
    if library_folder[-1] != "/" and library_folder[-1] != "\\": library_folder += "/"
    if not xbmcvfs.exists(library_folder):
        xbmcvfs.mkdir(library_folder)
        msg = "Would you like to automatically set Meta as a musicvideos source?"
        if dialogs.yesno("Library setup", msg):
            source_thumbnail = nav_base.get_icon_path("musicvideos")
            source_name = "Meta Music videos"
            source_content = "('%s','musicvideos','metadata.musicvideos.theaudiodb.com','',2147483647,0,'<settings><setting id=\"fanarttvalbumthumbs\" value=\"true\" /><setting id=\"tadbalbumthumbs\" value=\"true\" /></settings>',0,0,NULL,NULL)" %library_folder
            tools.add_source(source_name, library_folder, source_content, source_thumbnail)
    return xbmc.translatePath(library_folder)

def auto_musicvideos_setup(library_folder):
    if library_folder[-1] != "/" and library_folder[-1] != "\\": library_folder += "/"
    if not xbmcvfs.exists(library_folder):
        try:
            xbmcvfs.mkdir(library_folder)
            source_thumbnail = nav_base.get_icon_path("musicvideos")
            source_name = "Meta Music videos"
            source_content = "('%s','musicvideos','metadata.musicvideos.theaudiodb.com','',2147483647,0,'<settings><setting id=\"fanarttvalbumthumbs\" value=\"true\" /><setting id=\"tadbalbumthumbs\" value=\"true\" /></settings>',0,0,NULL,NULL)" %library_folder
            tools.add_source(source_name, library_folder, source_content, source_thumbnail)
            return True
        except: False