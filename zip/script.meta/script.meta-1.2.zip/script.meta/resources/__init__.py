from resources.lib.xswift2 import Plugin

plugin = Plugin()

def import_tmdb():
    from resources.lib import TheMovieDB
    __builtins__["tmdb"] = TheMovieDB