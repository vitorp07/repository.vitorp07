import re
import xbmc

def get_url(stream_file):
    return None

def main():
    stream_file = xbmc.getInfoLabel('ListItem.FileNameAndPath')
    url = get_url(stream_file)
    if url is None:
        if xbmc.getCondVisibility('Container.Content(movies)') == True:
            if xbmc.getInfoLabel('ListItem.IMDBNumber'): url = "plugin://script.meta/movies/play/imdb/%s/context" %xbmc.getInfoLabel('ListItem.IMDBNumber')
            elif xbmc.getInfoLabel('ListItem.Title'): url = "plugin://script.meta/movies/play_by_name/%s/en" %xbmc.getInfoLabel('ListItem.Title')
            else: url = "plugin://script.meta/movies/play_by_name/%s/en" %xbmc.getInfoLabel('ListItem.Label')
        elif xbmc.getCondVisibility('Container.Content(episodes)') == True: url = "plugin://script.meta/tv/play_by_name/%s/%s/%s/en/context" %(xbmc.getInfoLabel('ListItem.TVShowTitle'), xbmc.getInfoLabel('ListItem.Season'), xbmc.getInfoLabel('ListItem.Episode'))
        elif xbmc.getCondVisibility('Container.Content(artists)') == True or xbmc.getCondVisibility('Container.Content(albums)') == True or xbmc.getCondVisibility('Container.Content(songs)') == True or xbmc.getCondVisibility('Container.Content(musicvideos)') == True:
            if xbmc.getInfoLabel('ListItem.Artist') and xbmc.getInfoLabel('ListItem.Album') and xbmc.getInfoLabel('ListItem.Title'):
                if xbmc.getCondVisibility('Container.Content(musicvideos)') == True: url = "plugin://script.meta/music/play_video/%s/%s/%s/context" %(xbmc.getInfoLabel('ListItem.Artist'), xbmc.getInfoLabel('ListItem.Album'), xbmc.getInfoLabel('ListItem.Title'))
                else: url = "plugin://script.meta/music/play_audio/%s/%s/%s/context" %(xbmc.getInfoLabel('ListItem.Artist'), xbmc.getInfoLabel('ListItem.Album'), xbmc.getInfoLabel('ListItem.Title'))
            elif xbmc.getInfoLabel('ListItem.Artist') and xbmc.getInfoLabel('ListItem.Album'): url = "plugin://script.meta/music/artist/%s/album/%s/tracks" %(xbmc.getInfoLabel('ListItem.Artist'), xbmc.getInfoLabel('ListItem.Album'))
            elif xbmc.getInfoLabel('ListItem.Artist'): 
                url = "plugin://script.meta/music/artist/%s/albums/1" %xbmc.getInfoLabel('ListItem.Artist')
                return xbmc.executebuiltin("ActivateWindow(10025, %s)" %url)
            elif xbmc.getInfoLabel('ListItem.Album'): 
                url = "plugin://script.meta/music/search_album_term/%s/1" %xbmc.getInfoLabel('ListItem.Album')
                return xbmc.executebuiltin("ActivateWindow(10025, %s)" %url)
            elif xbmc.getInfoLabel('ListItem.Title'): 
                url = "plugin://script.meta/music/search_track_term/%s/1" %xbmc.getInfoLabel('ListItem.Title')
                return xbmc.executebuiltin("ActivateWindow(10025, %s)" %url)
        elif xbmc.getInfoLabel('ListItem.Label'): url = "plugin://script.meta/play/%s" %(re.sub(r'\[[^)].*?\]', '', xbmc.getInfoLabel('ListItem.Label')))
        else: 
            url = None
            return
        xbmc.executebuiltin("RunPlugin(%s)" %url)
    else: xbmc.executebuiltin("PlayMedia(%s)" %url)
    
if __name__ == '__main__': main()