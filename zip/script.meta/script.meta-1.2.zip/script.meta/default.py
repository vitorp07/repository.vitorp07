import os, time, shutil, traceback
import xbmc
import settings
from resources import plugin
from resources.lib import nav_base
from resources.lib import nav_movies
from resources.lib import nav_tvshows
from resources.lib import nav_musics
from resources.lib import nav_musicvideos
from resources.lib import lists
from resources.lib import lib_tvshows
from resources.lib import lib_movies
from resources.lib import lib_musics
from resources.lib import lib_musicvideos
from resources.lib import dialogs
from resources.lib import properties
from resources.lib import updater
from resources.lib import meta_players
from resources.lib import play_base

VIEW = plugin.get_setting(settings.SETTING_MAIN_VIEW, int)
FORCE = plugin.get_setting(settings.SETTING_FORCE_VIEW, bool)

@plugin.route('/')
def root():
    items = [{'label': "Movies", 'path': plugin.url_for("movies"), 'icon': nav_base.get_icon_path("movies")},
             {'label': "TV shows", 'path': plugin.url_for("tv"), 'icon': nav_base.get_icon_path("tv")},
             {'label': "Music videos", 'path': plugin.url_for("musicvideos"), 'icon': nav_base.get_icon_path("musicvideos")},
             {'label': "Music", 'path': plugin.url_for("music"), 'icon': nav_base.get_icon_path("music")},
             {'label': "Trakt collections", 'path': plugin.url_for("lists"), 'icon': nav_base.get_icon_path("trakt")},
             {'label': "Search", 'path': plugin.url_for("root_search"), 'icon': nav_base.get_icon_path("search")}]
    for item in items: item['properties'] = {'fanart_image': nav_base.get_background_path()}
    if FORCE == True: plugin.set_view_mode(VIEW); return items
    else: return items

@plugin.route('/clear_cache')
def clear_cache():
    for filename in os.listdir(plugin.storage_path):
        file_path = os.path.join(plugin.storage_path, filename)
        try:
            if os.path.isfile(file_path): os.unlink(file_path)
            elif os.path.isdir(file_path): shutil.rmtree(file_path)
        except Exception, e: traceback.print_exc()
    dialogs.notify(title="Cache", msg="Cleared", delay=2000, image=nav_base.get_icon_path("meta"))

@plugin.route('/update_library')
def update_library():
    is_updating = properties.get_property("updating_library")
    is_syncing = properties.get_property("syncing_library")
    now = time.time()
    if is_syncing and now - int(is_syncing) < plugin.get_setting(settings.SETTING_UPDATE_LIBRARY_INTERVAL, int) * 60: plugin.log.info("Skipping library sync")
    else:
        if plugin.get_setting(settings.SETTING_LIBRARY_SYNC_COLLECTION, bool) == True:
            try:
                properties.set_property("syncing_library", int(now))
                if plugin.get_setting(settings.SETTING_LIBRARY_SYNC_COLLECTION, bool) == True:
                    lib_tvshows.sync_trakt_collection()
                    lib_movies.sync_trakt_collection()
            except: plugin.log.info("something went wrong")
            finally: properties.clear_property("syncing_library")
        else: properties.clear_property("syncing_library")
    if is_updating and now - int(is_updating) < 120:
        plugin.log.debug("Skipping library update")
        return
    if plugin.get_setting(settings.SETTING_LIBRARY_UPDATES, bool) == True:
        try:
            properties.set_property("updating_library", int(now))
            lib_tvshows.update_library()
            lib_movies.update_library()
            lib_musics.update_library()
        finally: properties.clear_property("updating_library")
    else: properties.clear_property("updating_library")

@plugin.route('/settings/players/<media>')
def settings_set_players(media):
    playericon = nav_base.get_icon_path("meta")
    medias = ["movies", "tvshows", "musicvideos", "music"]
    if media == "all":
        for med in medias:
            mediatype = med.replace("es","e").replace("ws","w").replace("all","").replace("os","o").replace("vs","v s").replace("tv","TV").replace("musicvideo","Music video")
            players = meta_players.get_players(med)
            selected = [p.id for p in players]
            if selected is not None:
                if med == "movies": plugin.set_setting(settings.SETTING_MOVIES_ENABLED_PLAYERS, selected)
                elif med == "tvshows": plugin.set_setting(settings.SETTING_TV_ENABLED_PLAYERS, selected)
                elif med == "musicvideos": plugin.set_setting(settings.SETTING_MUSICVIDEOS_ENABLED_PLAYERS, selected)
                elif med == "music": plugin.set_setting(settings.SETTING_MUSIC_ENABLED_PLAYERS, selected)
                else: raise Exception("invalid parameter %s" %media)
            dialogs.notify(title="Players", msg="Enabled: %s"%mediatype.capitalize(), delay=1000, image=nav_base.get_icon_path("meta"))
        dialogs.notify(title="Players", msg="All enabled", delay=1000, image=nav_base.get_icon_path("meta"))
        return True
    else:
        mediatype = media.replace("es","e").replace("ws","w").replace("all","").replace("os","o").replace("vs","v s").replace("tv","TV").replace("musicvideo","Music video")
        players = meta_players.get_players(media)
        preselected = [p.id for p in play_base.active_players(media)]
        players_list = [p.clean_title for p in players]
        if media == "movies":
            players_on = sorted(["[B]%s[/B]" %(p.clean_title) for p in players if p.id in plugin.get_setting(settings.SETTING_MOVIES_ENABLED_PLAYERS, unicode)])
            players_off = sorted(["[I]%s[/I]" %(p.clean_title) for p in players if p.id not in plugin.get_setting(settings.SETTING_MOVIES_ENABLED_PLAYERS, unicode)])
        elif media == "tvshows":
            players_on = sorted(["[B]%s[/B]" %(p.clean_title) for p in players if p.id in plugin.get_setting(settings.SETTING_TV_ENABLED_PLAYERS, unicode)])
            players_off = sorted(["[I]%s[/I]" %(p.clean_title) for p in players if p.id not in plugin.get_setting(settings.SETTING_TV_ENABLED_PLAYERS, unicode)])
        elif media == "musicvideos":
            players_on = sorted(["[B]%s[/B]" %(p.clean_title) for p in players if p.id in plugin.get_setting(settings.SETTING_MUSICVIDEOS_ENABLED_PLAYERS, unicode)])
            players_off = sorted(["[I]%s[/I]" %(p.clean_title) for p in players if p.id not in plugin.get_setting(settings.SETTING_MUSICVIDEOS_ENABLED_PLAYERS, unicode)])
        elif media == "music":
            players_on = sorted(["[B]%s[/B]" %(p.clean_title) for p in players if p.id in plugin.get_setting(settings.SETTING_MUSIC_ENABLED_PLAYERS, unicode)])
            players_off = sorted(["[I]%s[/I]" %(p.clean_title) for p in players if p.id not in plugin.get_setting(settings.SETTING_MUSIC_ENABLED_PLAYERS, unicode)])
        players_total = players_off + players_on
        selected = None
        msg ="Enable all players?"
        if dialogs.yesno("Enable %s players" %mediatype, msg): selected = [p.id for p in players]
        else:
            result = dialogs.multiselect("Enable %s players" %mediatype, players_on + players_off)
            if result is not None: selected = [players[i].id for i in result]
        if selected is not None and selected != preselected:
            if media == "movies": plugin.set_setting(settings.SETTING_MOVIES_ENABLED_PLAYERS, selected)
            elif media == "tvshows": plugin.set_setting(settings.SETTING_TV_ENABLED_PLAYERS, selected)
            elif media == "musicvideos": plugin.set_setting(settings.SETTING_MUSICVIDEOS_ENABLED_PLAYERS, selected)
            elif media == "music": plugin.set_setting(settings.SETTING_MUSIC_ENABLED_PLAYERS, selected)
            else: raise Exception("invalid parameter %s" %media)

@plugin.route('/update_players')
@plugin.route('/update_players/<url>', name='update_players_url')
def update_players():
    if updater.update_players("https://api.github.com/repos/vitorp07/players/zipball"): dialogs.notify(title="Players update", msg="Done", delay=1000, image=nav_base.get_icon_path("meta"))
    else: dialogs.notify(title="Players update", msg="Failed", delay=1000, image=nav_base.get_icon_path("meta"))
    plugin.open_settings()

@plugin.route('/setup/total')
def total_setup():
    dialogs.notify(title="Total Setup", msg="Started", delay=500, image=nav_base.get_icon_path("meta"))
    if sources_setup() == True: pass
    if players_setup() == True: pass
    xbmc.sleep(1000)
    dialogs.notify(title="Total Setup", msg="Done", delay=2000, image=nav_base.get_icon_path("meta"))

@plugin.route('/setup/silent')
def silent_setup():
    xbmc.executebuiltin('SetProperty(running,totalmeta,home)')
    movielibraryfolder = plugin.get_setting(settings.SETTING_MOVIES_LIBRARY_FOLDER, unicode)
    try: lib_movies.auto_movie_setup(movielibraryfolder)
    except: pass
    tvlibraryfolder = plugin.get_setting(settings.SETTING_TV_LIBRARY_FOLDER, unicode)
    try: lib_tvshows.auto_tvshows_setup(tvlibraryfolder)
    except: pass
    musicvideoslibraryfolder = plugin.get_setting(settings.SETTING_MUSICVIDEOS_LIBRARY_FOLDER, unicode)
    try: lib_musicvideos.auto_musicvideos_setup(musicvideoslibraryfolder)
    except: pass
    musiclibraryfolder = plugin.get_setting(settings.SETTING_MUSIC_LIBRARY_FOLDER, unicode)
    try: lib_musics.auto_music_setup(musiclibraryfolder)
    except: pass
    xbmc.executebuiltin('ClearProperty(running,home)')

@plugin.route('/setup/players')
def players_setup():
    properties.set_property('running','totalmeta')
    if updater.update_players("https://api.github.com/repos/vitorp07/players/zipball"): dialogs.notify(title="Players setup", msg="Done", delay=1000, image=nav_base.get_icon_path("meta"))
    else: dialogs.notify(title="Players setup", msg="Failed", delay=1000, image=nav_base.get_icon_path("meta"))
    xbmc.executebuiltin('RunPlugin(plugin://script.meta/settings/players/all/)')
    properties.clear_property('running')
    return True

@plugin.route('/setup/sources')
def sources_setup():
    movielibraryfolder = plugin.get_setting(settings.SETTING_MOVIES_LIBRARY_FOLDER, unicode)
    try:
        lib_movies.auto_movie_setup(movielibraryfolder)
        dialogs.notify(title="Movies source setup", msg="Done", delay=1000, image=nav_base.get_icon_path("movies"))
    except: dialogs.notify(title="Movies source setup", msg="Failed", delay=1000, image=nav_base.get_icon_path("movies"))
    tvlibraryfolder = plugin.get_setting(settings.SETTING_TV_LIBRARY_FOLDER, unicode)
    try:
        lib_tvshows.auto_tvshows_setup(tvlibraryfolder)
        dialogs.notify(title="TV shows source setup", msg="Done", delay=1000, image=nav_base.get_icon_path("tv"))
    except: dialogs.notify(title="TV shows source setup", msg="Failed", delay=1000, image=nav_base.get_icon_path("tv"))
    musicvideoslibraryfolder = plugin.get_setting(settings.SETTING_MUSICVIDEOS_LIBRARY_FOLDER, unicode)
    try:
        lib_musicvideos.auto_musicvideos_setup(musicvideoslibraryfolder)
        dialogs.notify(title="Music videos source setup", msg="Done", delay=1000, image=nav_base.get_icon_path("musicvideos"))
    except: dialogs.notify(title="Music videos source setup", msg="Failed", delay=1000, image=nav_base.get_icon_path("musicvideos"))
    musiclibraryfolder = plugin.get_setting(settings.SETTING_MUSIC_LIBRARY_FOLDER, unicode)
    try:
        lib_musics.auto_music_setup(musiclibraryfolder)
        dialogs.notify(title="Music source setup", msg="Done", delay=1000, image=nav_base.get_icon_path("music"))
    except: dialogs.notify(title="Music source setup", msg="Failed", delay=1000, image=nav_base.get_icon_path("music"))
    return True

@plugin.route('/search')
def root_search():
    term = plugin.keyboard(heading="Enter search string")
    if term != None and term != "": return root_search_term(term)
    else: return

@plugin.route('/search/edit/<term>')
def root_search_edit(term):
    if term == " " or term == None or term == "": term = plugin.keyboard(heading="Enter search string")
    else: term = plugin.keyboard(default=term, heading="Enter search string")
    if term != None and term != "": return root_search_term(term)
    else: return

@plugin.route('/search_term/<term>', options = {"term": "None"})
def root_search_term(term):
    items = [{'label': "Movies (TMDb) search - %s" %term, 'path': plugin.url_for("tmdb_movies_search_term", term=term, page='1'), 'icon': nav_base.get_icon_path("movies")},
             {'label': "Movies (Trakt) search - %s" %term, 'path': plugin.url_for("trakt_movies_search_term", term=term, page='1'), 'icon': nav_base.get_icon_path("movies")},
             {'label': "TV shows (TVDb) search - %s" %term, 'path': plugin.url_for("tvdb_tv_search_term", term=term, page='1'), 'icon': nav_base.get_icon_path("tv")},
             {'label': "TV shows (TMDb) search - %s" %term, 'path': plugin.url_for("tmdb_tv_search_term", term=term, page='1'), 'icon': nav_base.get_icon_path("tv")},
             {'label': "TV shows (Trakt) search - %s" %term, 'path': plugin.url_for("trakt_tv_search_term", term=term, page='1'), 'icon': nav_base.get_icon_path("tv")},
             {'label': "Artists (LastFM) search - %s" %term, 'path': plugin.url_for("music_search_artist_term", term=term, page='1'), 'icon': nav_base.get_icon_path("music")},
             {'label': "Albums (LastFM) search - %s" %term, 'path': plugin.url_for("music_search_album_term", term=term, page='1'), 'icon': nav_base.get_icon_path("music")},
             {'label': "Tracks (LastFM) search - %s" %term, 'path': plugin.url_for("music_search_track_term", term=term, page='1'), 'icon': nav_base.get_icon_path("music")},
             {'label': "Edit search string", 'path': plugin.url_for("root_search_edit", term=term), 'icon': nav_base.get_icon_path("search")}]
    for item in items: item['properties'] = {'fanart_image': nav_base.get_background_path()}
    return items

@plugin.route('/play/<label>')
def play_by_label(label):
    types = ["Movies", "TV shows"]
    selection = dialogs.select("Search for '%s'" %label, [item for item in types])
    if selection   == 0: xbmc.executebuiltin('RunPlugin(plugin://script.meta/movies/play_by_name/%s/en)' %label)
    elif selection == 1: xbmc.executebuiltin('RunPlugin(plugin://script.meta/tv/play_by_name/%s/%s/%s/%s/en)' %(xbmc.getInfoLabel('ListItem.TVShowTitle'), xbmc.getInfoLabel('ListItem.Season'), xbmc.getInfoLabel('ListItem.Episode'), label))

@plugin.route('/cleartrakt')
def clear_trakt():
    if dialogs.yesno("Clear Trakt account settings?", msg="Reauthorizing Trakt will be required to access Trakt collections"):
        plugin.set_setting(settings.SETTING_TRAKT_ACCESS_TOKEN, "")
        plugin.set_setting(settings.SETTING_TRAKT_REFRESH_TOKEN, "")
        plugin.set_setting(settings.SETTING_TRAKT_EXPIRES_AT, "")

def main():
    from sys import argv
    from xbmcplugin import setContent
    if '/movies' in argv[0]: setContent(int(argv[1]), 'movies')
    elif '/tv' in argv[0]: setContent(int(argv[1]), 'tvshows')
    elif '/list' in argv[0]: setContent(int(argv[1]), 'movies')
    elif '/music' in argv[0]: setContent(int(argv[1]), 'songs')
    elif '/musicvideos' in argv[0]: setContent(int(argv[1]), 'musicvideos')
    plugin.run()

if __name__ == '__main__': main()