import math
import xbmcgui, xbmcplugin
import settings
from resources import plugin
from resources.lib.text import to_utf8
from resources.lib import play_musicvideos
from resources.lib import play_musics
from resources.lib import nav_base
from resources.lib import lib_musics
from resources.lib import tools
from resources.lib import Last_fm

SORT = [xbmcplugin.SORT_METHOD_UNSORTED, xbmcplugin.SORT_METHOD_LABEL]
FORCE = plugin.get_setting(settings.SETTING_FORCE_VIEW, bool)
VIEW  = plugin.get_setting(settings.SETTING_MUSIC_VIEW, int)

@plugin.route('/music')
def music():
    items = [{'label': "Top 100 Tracks", 'path': plugin.url_for("music_top_tracks"), 'icon': nav_base.get_icon_path("trending")},
             {'label': "Top 100 Artists", 'path': plugin.url_for("music_top_artists"), 'icon': nav_base.get_icon_path("top_rated")},
             {'label': "Top 100 Tracks (US)", 'path': plugin.url_for("music_top_tracks_by_country", country='united states'), 'icon': nav_base.get_icon_path("trending_us")},
             {'label': "Top 100 Artists (US)", 'path': plugin.url_for("music_top_artists_by_country", country='united states'), 'icon': nav_base.get_icon_path("top_us")},
             {'label': "Top 100 Tracks (UK)", 'path': plugin.url_for("music_top_tracks_by_country", country='united kingdom'), 'icon': nav_base.get_icon_path("trending_uk")},
             {'label': "Top 100 Artists (UK)", 'path': plugin.url_for("music_top_artists_by_country", country='united kingdom'), 'icon': nav_base.get_icon_path("top_uk")},
             {'label': "Search Music", 'path': plugin.url_for("music_search"), 'icon': nav_base.get_icon_path("search")}]
    for item in items: item['properties'] = {'fanart_image': nav_base.get_background_path()}
    if FORCE == True: plugin.set_view_mode(VIEW); return items
    else: return items

@plugin.route('/music/search')
def music_search():
    term = plugin.keyboard(heading="Enter search string")
    if term != None and term != "": return music_search_term(term, 1)
    else: return

@plugin.route('/music/search/edit/<term>')
def music_search_edit(term):
    term = plugin.keyboard(default=term, heading="Enter search string")
    if term != None and term != "": return music_search_term(term, 1)
    else: return

@plugin.route('/music/search/<term>/<page>')
def music_search_term(term, page):
    items = [{'label': "%s: '%s' - %s (%s)" %("Search", term, "Albums", "LastFM"),
              'path': plugin.url_for("music_search_album_term", term=term, page='1'),
              'icon': nav_base.get_icon_path("music")},
             {'label': "%s: '%s' - %s (%s)" %("Search", term, "Artists", "LastFM"),
              'path': plugin.url_for("music_search_artist_term", term=term, page='1'),
              'icon': nav_base.get_icon_path("music")},
             {'label': "%s: '%s' - %s (%s)" %("Search", term, "Tracks", "LastFM"),
              'path': plugin.url_for("music_search_track_term", term=term, page='1'),
              'icon': nav_base.get_icon_path("music")},
             {'label': "Edit search string",
              'path': plugin.url_for("music_search_edit", term=term),
              'icon': nav_base.get_icon_path("search")}]
    for item in items:
        item['properties'] = {'fanart_image' : nav_base.get_background_path()}
    if FORCE == True: plugin.set_view_mode(VIEW); return items
    else: return items

@plugin.route('/music/search/artist')
def music_search_artist():
    term = plugin.keyboard(heading="Enter search string")
    return music_search_artist_term(term, 1)

@plugin.route('/music/search/album')
def music_search_album():
    term = plugin.keyboard(heading="Enter search string")
    return music_search_album_term(term, 1)

@plugin.route('/music/search/track')
def music_search_track():
    term = plugin.keyboard(heading="Enter search string")
    return music_search_track_term(term, 1)

@plugin.route('/music/top_artists/<page>', options={'page': "1"})
def music_top_artists(page):
    results = Last_fm.get_top_artists(page)
    artists = results["artists"]["artist"]
    items = []
    for artist in artists:
        large_image = artist["image"][-1]["#text"]
        name = to_utf8(artist["name"])
        context_menu = [("add to library", "RunPlugin(%s)" %(plugin.url_for("music_add_artist_to_library", artist_name=name)))]
        item = {'label': name,
                'path': plugin.url_for("music_artist_albums", artist_name=name),
                'thumbnail': large_image,
                'icon': "DefaultMusic.png",
                'poster': large_image,
                'info': {'artist': name},
                'info_type': 'music',
                'context_menu': context_menu}
        items.append(item)
    if FORCE == True: plugin.set_view_mode(VIEW); return items
    else: return items

@plugin.route('/music/top_tracks/<page>', options={'page': "1"})
def music_top_tracks(page):
    results = Last_fm.get_top_tracks(page)
    tracks = results["tracks"]["track"]
    items = []
    for track in tracks:
        large_image = track["image"][-1]["#text"]
        track_name = to_utf8(track["name"])
        artist_name = to_utf8(track["artist"]["name"])
        path = plugin.url_for("music_play_audio", artist_name=artist_name, track_name=track_name)
        icon = "DefaultMusic.png"
        info_type = "music"
        context_menu = [("Play", "PlayMedia(%s)" %(plugin.url_for("music_play_audio", artist_name=artist_name, track_name=track_name, mode="context"))),
                        ("Play (music video)", "RunPlugin(%s)" %(plugin.url_for("music_play_video", artist_name=artist_name, track_name=track_name, mode="context"))),
                        ("Add to library", "RunPlugin(%s)" %(plugin.url_for("music_add_to_library", artist_name=artist_name, track_name=track_name)))]
        item = {'label': "%s - %s" %(artist_name, track_name),
                'path': path,
                'thumbnail': large_image,
                'icon': icon,
                'poster': large_image,
                'info': {'artist': artist_name},
                'info_type': info_type,
                'context_menu': context_menu}
        items.append(item)
    if FORCE == True: plugin.set_view_mode(VIEW); return items
    else: return items

@plugin.route('/music/top_artists_by_country/<country>/<page>', options={'page': "1"})
def music_top_artists_by_country(country, page):
    results = Last_fm.get_top_artists_by_country(country, page)
    artists = results["topartists"]["artist"]
    items = []
    for artist in artists:
        large_image = artist["image"][-1]["#text"]
        name = to_utf8(artist["name"])
        context_menu = [("Add to library", "RunPlugin(%s)" %(plugin.url_for("music_add_artist_to_library", artist_name=name)))]
        item = {'label': name,
                'path': plugin.url_for("music_artist_albums", artist_name=name),
                'thumbnail': large_image,
                'icon': "DefaultMusic.png",
                'poster': large_image,
                'info': {'artist': name},
                'info_type': 'music',
                'context_menu': context_menu}
        items.append(item)
    if FORCE == True: plugin.set_view_mode(VIEW); return items
    else: return items

@plugin.route('/music/top_tracks_by_country/<country>/<page>', options={'page': "1"})
def music_top_tracks_by_country(country, page):
    results = Last_fm.get_top_tracks_by_country(country, page)
    tracks = results["tracks"]["track"]
    items = []
    for track in tracks:
        large_image = track["image"][-1]["#text"]
        track_name = to_utf8(track["name"])
        artist_name = to_utf8(track["artist"]["name"])
        context_menu = [("Play", "PlayMedia(%s)" %(plugin.url_for("music_play_audio", artist_name=artist_name, track_name=track_name, mode="context"))),
                        ("Play (music video)", "RunPlugin(%s)" %(plugin.url_for("music_play_video", artist_name=artist_name, track_name=track_name, mode="context"))),
                        ("Add to library", "RunPlugin(%s)" %(plugin.url_for("music_add_to_library", artist_name=artist_name, track_name=track_name)))]
        item = {'label': "%s - %s" %(artist_name, track_name),
                'path': plugin.url_for("music_play_audio", artist_name=artist_name, track_name=track_name),
                'thumbnail': large_image,
                'icon': "DefaultMusic.png",
                'poster': large_image,
                'info': {'artist': artist_name},
                'info_type': 'music',
                'context_menu': context_menu}
        items.append(item)
    if FORCE == True: plugin.set_view_mode(VIEW); return items
    else: return items

@plugin.route('/music/search_artist_term/<term>/<page>')
def music_search_artist_term(term, page):
    search_results = Last_fm.search_artist(term, page)
    artists = search_results["artistmatches"]["artist"]
    items_per_page = search_results["opensearch:itemsPerPage"]
    start_index = search_results["opensearch:startIndex"]
    total_results = search_results["opensearch:totalResults"]
    items = []
    for artist in artists:
        large_image = artist["image"][-1]["#text"]
        name = to_utf8(artist["name"])
        context_menu = [("Add to library", "RunPlugin(%s)" %(plugin.url_for("music_add_artist_to_library", artist_name=name)))]
        item = {'label': name,
                'path': plugin.url_for("music_artist_albums", artist_name=name),
                'thumbnail': large_image,
                'icon': "DefaultMusic.png",
                'poster': large_image,
                'info': {'artist': name},
                'info_type': 'music',
                'context_menu': context_menu}
        items.append(item)
    if start_index + items_per_page < total_results:
        items.append({'label': "Next page >>",
                      'icon': nav_base.get_icon_path("item_next"),
                      'path': plugin.url_for("music_search_artist_term", term=term, page=int(page) + 1)})
    if FORCE == True: plugin.set_view_mode(VIEW); return items
    else: return items

@plugin.route('/music/search_album_term/<term>/<page>')
def music_search_album_term(term, page):
    search_results = Last_fm.search_album(term, page)
    albums = search_results["albummatches"]["album"]
    items_per_page = search_results["opensearch:itemsPerPage"]
    start_index = search_results["opensearch:startIndex"]
    total_results = search_results["opensearch:totalResults"]
    items = []
    for album in albums:
        large_image = album["image"][-1]["#text"]
        album_name = to_utf8(album["name"])
        artist_name = to_utf8(album["artist"])
        context_menu = [("Add to library", "RunPlugin(%s)" %(plugin.url_for("music_add_album_to_library", artist_name=artist_name, album_name=album_name)))]
        item = {'label': "%s - %s" %(artist_name, album_name),
                'path': plugin.url_for("music_artist_album_tracks", artist_name=artist_name, album_name=album_name),
                'thumbnail': large_image,
                'icon': "DefaultMusic.png",
                'poster': large_image,
                'info': {'artist': artist_name},
                'info_type': 'music',
                'context_menu': context_menu}
        items.append(item)
    if start_index + items_per_page < total_results:
        items.append({'label': "Next page >>",
                      'icon': nav_base.get_icon_path("item_next"),
                      'path': plugin.url_for("music_search_album_term", term=term, page=int(page) + 1)})
    if FORCE == True: plugin.set_view_mode(VIEW); return items
    else: return items

@plugin.route('/music/search_track_term/<term>/<page>')
def music_search_track_term(term, page):
    search_results = Last_fm.search_track(term, page)
    tracks = search_results["trackmatches"]["track"]
    items_per_page = search_results["opensearch:itemsPerPage"]
    start_index = search_results["opensearch:startIndex"]
    total_results = search_results["opensearch:totalResults"]
    items = []
    for track in tracks:
        large_image = track["image"][-1]["#text"]
        track_name = to_utf8(track["name"])
        artist_name = to_utf8(track["artist"])
        context_menu = [("Play", "PlayMedia(%s)" %(plugin.url_for("music_play_audio", artist_name=artist_name, track_name=track_name, mode="context"))),
                        ("Play (music video)", "RunPlugin(%s)" %(plugin.url_for("music_play_video", artist_name=artist_name, track_name=track_name, mode="context"))),
                        ("Add to library", "RunPlugin(%s)" %(plugin.url_for("music_add_to_library", artist_name=artist_name, track_name=track_name)))]
        item = {'label': "%s - %s" %(artist_name, track_name),
                'path': plugin.url_for("music_play_audio", artist_name=artist_name, track_name=track_name),
                'thumbnail': large_image,
                'icon': "DefaultMusic.png",
                'poster': large_image,
                'info': {'artist': artist_name},
                'info_type': 'music',
                'context_menu': context_menu}
        items.append(item)
    if start_index + items_per_page < total_results:
        items.append({'label': "Next >>",
                      'icon': nav_base.get_icon_path("item_next"),
                      'path': plugin.url_for("music_search_track_term", term=term, page=int(page) + 1)})
    if FORCE == True: plugin.set_view_mode(VIEW); return items
    else: return items

@plugin.route('/music/artist/<name>')
def music_artist(name):
    name = to_utf8(name)
    items = [{'label': "Tracks",
              'path': plugin.url_for("music_artist_tracks", artist_name=name),
              'icon': nav_base.get_icon_path("music")},
             {'label': "Albums",
              'path': plugin.url_for("music_artist_albums", artist_name=name),
              'icon': nav_base.get_icon_path("music")}]
    if FORCE == True: plugin.set_view_mode(VIEW); return items
    else: return items

@plugin.route('/music/artist/<artist_name>/tracks/<page>', options={'page': "1"})
def music_artist_tracks(artist_name, page):
    artist_name = to_utf8(artist_name)
    results = Last_fm.get_artist_top_tracks(artist_name, page)
    items = []
    for track in results["track"]:
        large_image = track["image"][-1]["#text"]
        track_name = to_utf8(track["name"])
        context_menu = [("Play", "PlayMedia(%s)" %(plugin.url_for("music_play_audio", artist_name=artist_name, track_name=track_name, mode="context"))),
                        ("Play (music video)", "PlayMedia(%s)" %(plugin.url_for("music_play_video", artist_name=artist_name, track_name=track_name, mode="context"))),
                        ("Add to library", "RunPlugin(%s)" %(plugin.url_for("music_add_to_library", artist_name=artist_name, track_name=track_name)))]
        item = {'label': track_name,
                'path': plugin.url_for("music_play_audio", artist_name=artist_name, track_name=track_name),
                'thumbnail': large_image,
                'icon': "DefaultMusic.png",
                'poster': large_image,
                'info_type': 'music',
                'context_menu': context_menu}
        items.append(item)
    if results["@attr"]["totalPages"] > page:
        items.append({'label': "Next >>",
                      'icon': nav_base.get_icon_path("item_next"),
                      'path': plugin.url_for("music_artist_tracks", artist_name=artist_name, page=int(page) + 1)})
    if FORCE == True: plugin.set_view_mode(VIEW); return items
    else: return items

@plugin.route('/music/artist/<artist_name>/albums/<page>', options={'page': "1"})
def music_artist_albums(artist_name, page):
    artist_name = to_utf8(artist_name)
    results = Last_fm.get_artist_top_albums(artist_name, page)
    items = [{'label': "All Tracks",
              'path': plugin.url_for("music_artist_tracks", artist_name=artist_name),
              'icon': nav_base.get_icon_path("music")}]
    for album in results["album"]:
        album_name = to_utf8(album["name"])
        image = album['image'][-1]['#text']
        artist_album_name = to_utf8(album['artist']['name'])
        context_menu = [("Add to library", "RunPlugin(%s)" %(plugin.url_for("music_add_album_to_library", artist_name=artist_album_name, album_name=album_name)))]
        item = {'thumbnail': image,
                'label': "%s" %album_name,
                'info': {'title': album_name, 'artist': [artist_album_name]},
                'info_type': 'music',
                'path': plugin.url_for("music_artist_album_tracks", artist_name=artist_name, album_name=album_name),
                'context_menu': context_menu}
        items.append(item)
    if results["@attr"]["totalPages"] > page:
        next_page = int(page) + 1
        items.append({'label': "Next >>",
                      'icon': nav_base.get_icon_path("item_next"),
                      'path': plugin.url_for("music_artist_albums", artist_name=artist_name, page=next_page)})
    if FORCE == True: plugin.set_view_mode(VIEW); return items
    else: return items

@plugin.route('/music/artist/<artist_name>/album/<album_name>/tracks')
def music_artist_album_tracks(artist_name, album_name):
    artist_name = to_utf8(artist_name)
    album_name = to_utf8(album_name)
    results = Last_fm.get_album_info(artist_name, album_name)
    items = []
    for track in results["tracks"]["track"]:
        track_name = to_utf8(track["name"])
        track_number = track["@attr"]["rank"]
        image = results["image"][-1]["#text"]
        context_menu = [("Play", "PlayMedia(%s)" %(plugin.url_for("music_play_audio", artist_name=artist_name, track_name=track_name, mode="context"))),
                        ("Play (music video)", "RunPlugin(%s)" %(plugin.url_for("music_play_video", artist_name=artist_name, track_name=track_name, mode="context"))),
                        ("Add to library", "RunPlugin(%s)" %(plugin.url_for("music_add_to_library", artist_name=artist_name, track_name=track_name, album_name=album_name)))]
        item = {'label': "%s. %s" %(track_number, track_name),
                'path': plugin.url_for("music_play_audio", artist_name=artist_name, album_name=album_name, track_name=track_name),
                'thumbnail': image,
                'icon': "DefaultMusic.png",
                'poster': image,
                'info_type': 'music',
                'context_menu': context_menu,}
        items.append(item)
    if FORCE == True: plugin.set_view_mode(VIEW); return items
    else: return items

@plugin.route('/music/play/<artist_name>/<track_name>/<album_name>/<mode>', options={'album_name': "None", 'mode': 'default'})
def music_play(artist_name, track_name, album_name, mode):
    items = [{'label': "Play audio", 'path': plugin.url_for("music_play_audio", artist_name=artist_name, track_name=track_name, album_name=album_name, mode=mode)},
             {'label': "Play video", 'path': plugin.url_for("music_play_video", artist_name=artist_name, track_name=track_name, album_name=album_name, mode=mode)}]
    music_play_audio(artist_name, track_name, album_name, mode)

@plugin.route('/music/play_audio/<artist_name>/<track_name>/<album_name>/<mode>', options={'album_name': "None", 'mode': 'default'})
def music_play_audio(artist_name, track_name, album_name, mode):
    if album_name == "None":
        track_info = Last_fm.get_track_info(artist_name, track_name)
        if track_info and "album" in track_info:
            album_name = track_info["album"]["title"]
    play_musics.play_music(artist_name, track_name, album_name, mode)

@plugin.route('/music/play_video/<artist_name>/<track_name>/<album_name>/<mode>', options={'album_name': "None", 'mode': 'default'})
def music_play_video(artist_name, track_name, album_name, mode):
    if album_name == "None":
        track_info = Last_fm.get_track_info(artist_name, track_name)
        if track_info and "album" in track_info:
            album_name = track_info["album"]["title"]
    play_musicvideos.play_musicvideo(artist_name, track_name, album_name, mode)

@plugin.route('/music/add_to_library/<artist_name>/<track_name>/<album_name>', options={'album_name': "None"})
def music_add_to_library(artist_name, track_name, album_name):
    if album_name == "None":
        album_name = Last_fm.get_track_info(artist_name, track_name)["album"]["title"]
    library_folder = lib_musics.setup_library(plugin.get_setting(settings.SETTING_MUSIC_LIBRARY_FOLDER, unicode))
    lib_musics.add_music_to_library(library_folder, artist_name, album_name, track_name)
    tools.scan_library(type="music")

@plugin.route('/music/add_album_to_library/<artist_name>/<album_name>')
def music_add_album_to_library(artist_name, album_name):
    library_folder = lib_musics.setup_library(plugin.get_setting(settings.SETTING_MUSIC_LIBRARY_FOLDER, unicode))
    results = Last_fm.get_album_info(artist_name, album_name)
    for track in results["tracks"]["track"]:
        track_name = to_utf8(track["name"])
        lib_musics.add_music_to_library(library_folder, artist_name, album_name, track_name)
    tools.scan_library(type="music")

@plugin.route('/music/add_artist_to_library/<artist_name>')
def music_add_artist_to_library(artist_name):
    library_folder = lib_musics.setup_library(plugin.get_setting(settings.SETTING_MUSIC_LIBRARY_FOLDER, unicode))
    album_results = Last_fm.get_artist_top_albums(artist_name)
    total_albums = len(album_results)
    index = 0
    pDialog = xbmcgui.DialogProgress()
    pDialog.create('Meta', "Adding", artist_name, "to library")
    for album in album_results["album"]:
        album_name = to_utf8(album["name"])
        percent_done = int(math.floor((float(index) / total_albums) * 100))
        pDialog.update(percent_done, "Adding", artist_name, album_name, "to library")
        track_results = Last_fm.get_album_info(artist_name, album_name)
        for track in track_results["tracks"]["track"]:
            if pDialog.iscanceled():
                pDialog.update(0)
                return
            track_name = to_utf8(track["name"])
            lib_musics.add_music_to_library(library_folder, artist_name, album_name, track_name)
        index += 1
        pDialog.update(0)
    tools.scan_library(type="music")