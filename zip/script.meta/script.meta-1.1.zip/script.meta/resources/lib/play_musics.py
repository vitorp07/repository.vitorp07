import re
import xbmc
from resources.lib import text
from resources.lib import meta_players
from resources.lib import play_base

def play_music(artist_name, track_name, album_name, mode):
    play_plugin = meta_players.ADDON_SELECTOR.id
    players = play_base.active_players("music")
    players = [p for p in players if p.id == play_plugin] or players
    if not players:
        xbmc.executebuiltin("Action(Info)")
        play_base.action_cancel()
        return
    params = {}
    for lang in meta_players.get_needed_langs(players):
        params[lang] = get_music_parameters(artist_name, album_name, track_name)
        params[lang] = text.to_unicode(params[lang])
    link = play_base.on_play_video(mode, players, params)
    if link: play_base.action_play({'label': "%s - %s - %s" %(artist_name, album_name, track_name), 'path': link, 'is_playable': True, 'info_type': 'music'})

def get_music_parameters(artist_name, album_name, track_name):
    parameters = {}
    parameters["artist"] = artist_name
    parameters['clearartist'] = re.sub("(\(.*?\))", "", artist_name).strip()
    parameters["album"] = album_name
    parameters['clearalbum'] = re.sub("(\(.*?\))", "", album_name).strip()
    parameters["track"] = track_name
    parameters['cleartrack'] = re.sub("(\(.*?\))", "", track_name).strip()
    return parameters