import xbmcgui
from resources.lib import Utils
from resources.lib import YouTube
from resources.lib.WindowManager import wm
from resources.lib.VideoPlayer import PLAYER
from resources.lib.OnClickHandler import OnClickHandler
from resources.lib.DialogBaseList import DialogBaseList

ch = OnClickHandler()
SORTS = {'video'   : {'date': 'Date',
                      'rating': 'Rating',
                      'relevance': 'Relevance',
                      'title': 'Title',
                      'viewCount': 'Play count'},
         'playlist': {'date': 'Date',
                      'rating': 'Rating',
                      'relevance': 'Relevance',
                      'title': 'Title',
                      'viewCount': 'Play count',
                      'videoCount': 'Amount of videos'},
         'channel' : {'date': 'Date',
                      'rating': 'Rating',
                      'relevance': 'Relevance',
                      'title': 'Title',
                      'viewCount': 'Play count',
                      'videoCount': 'Amount of videos'}}

def get_youtube_window(window_type):
    class DialogYoutubeList(DialogBaseList, window_type):

        def __init__(self, *args, **kwargs):
            super(DialogYoutubeList, self).__init__(*args, **kwargs)
            self.type = kwargs.get('type', 'video')
            self.filter_url = ''
            self.page_token = ''
            self.next_page_token = ''
            self.prev_page_token = ''
            self.sort = kwargs.get('sort', 'relevance')
            self.sort_label = kwargs.get('sort_label', 'Relevance')
            self.page = int(kwargs.get('page', 1))
            self.order = kwargs.get('order', 'desc')
            force = kwargs.get('force', False)
            self.update_content(force_update=force)

        def onClick(self, control_id):
            super(DialogYoutubeList, self).onClick(control_id)
            ch.serve(control_id, self)

        def onAction(self, action):
            super(DialogYoutubeList, self).onAction(action)
            ch.serve_action(action, self.getFocusId(), self)

        @ch.click(500)
        def main_list_click(self):
            self.last_position = self.control.getSelectedPosition()
            youtube_id = self.listitem.getProperty('youtube_id')
            if self.type == 'channel':
                channel_filter = [{'id': youtube_id,
                                   'type': 'channelId',
                                   'typelabel': 'Channel',
                                   'label': youtube_id}]
                wm.open_youtube_list(filters=channel_filter)
            elif self.type == 'playlist': PLAYER.play_youtube_playlist(youtube_id=youtube_id, listitem=self.listitem, window=self)
            else: PLAYER.play_youtube_video(youtube_id=youtube_id, listitem=self.listitem, window=self)

        @ch.click(5002)
        def set_published_filter(self):
            label_list = ['One day', 'One week', 'One month', 'One year', 'Custom']
            deltas = [1, 7, 31, 365, 'custom']
            index = xbmcgui.Dialog().select(heading='Choose option', list=label_list)
            if index == -1: return None
            delta = deltas[index]
            if delta == 'custom': delta = xbmcgui.Dialog().input(heading='Amount of days', type=xbmcgui.INPUT_NUMERIC)
            if delta:
                d = datetime.datetime.now() - datetime.timedelta(int(delta))
                date_str = d.isoformat('T')[:-7] + 'Z'
                self.add_filter('publishedAfter', date_str, 'Release date'.replace(':',''), str(label_list[index]))
                self.update()

        @ch.click(5003)
        def set_language_filter(self):
            label_list = ['US', 'CA', 'PT', 'DE', 'ES', 'FR', 'NL', 'Other...']
            secondary_list = ['AD', 'AE', 'AF', 'AG', 'AI', 'AL', 'AM', 'AO', 'AQ', 'AR', 'AS', 'AT', 'AU', 'AW', 'AX', 'AZ', 'BA', 'BB', 'BD', 'BE', 'BF', 'BG',
                              'BH', 'BI', 'BJ', 'BL', 'BM', 'BN', 'BO', 'BQ', 'BR', 'BS', 'BT', 'BV', 'BW', 'BY', 'BZ', 'CC', 'CD', 'CF', 'CG', 'CH', 'CI', 'CK',
                              'CL', 'CM', 'CN', 'CO', 'CR', 'CU', 'CV', 'CW', 'CX', 'CY', 'CZ', 'DJ', 'DK', 'DM', 'DO', 'DZ', 'EC', 'EE', 'EG', 'EH', 'ER', 'ET',
                              'FI', 'FJ', 'FK', 'FM', 'FO', 'GA', 'GB', 'GD', 'GE', 'GF', 'GG', 'GH', 'GI', 'GL', 'GM', 'GN', 'GP', 'GQ', 'GR', 'GS', 'GT', 'GU',
                              'GW', 'GY', 'HK', 'HM', 'HN', 'HR', 'HT', 'HU', 'ID', 'IE', 'IL', 'IM', 'IN', 'IO', 'IQ', 'IR', 'IS', 'IT', 'JE', 'JM', 'JO', 'JP',
                              'KE', 'KG', 'KH', 'KI', 'KM', 'KN', 'KP', 'KR', 'KW', 'KY', 'KZ', 'LA', 'LB', 'LC', 'LI', 'LK', 'LR', 'LS', 'LT', 'LU', 'LV', 'LY',
                              'MA', 'MC', 'MD', 'ME', 'MF', 'MG', 'MH', 'MK', 'ML', 'MM', 'MN', 'MO', 'MP', 'MQ', 'MR', 'MS', 'MT', 'MU', 'MV', 'MW', 'MX', 'MY',
                              'MZ', 'NA', 'NC', 'NE', 'NF', 'NG', 'NI', 'NO', 'NP', 'NR', 'NU', 'NZ', 'OM', 'PA', 'PE', 'PF', 'PG', 'PH', 'PK', 'PL', 'PM', 'PN',
                              'PR', 'PS', 'PW', 'PY', 'QA', 'RE', 'RO', 'RS', 'RU', 'RW', 'SA', 'SB', 'SC', 'SD', 'SE', 'SG', 'SH', 'SI', 'SJ', 'SK', 'SL', 'SM',
                              'SN', 'SO', 'SR', 'SS', 'ST', 'SV', 'SX', 'SY', 'SZ', 'TC', 'TD', 'TF', 'TG', 'TH', 'TJ', 'TK', 'TL', 'TM', 'TN', 'TO', 'TR', 'TT',
                              'TV', 'TW', 'TZ', 'UA', 'UG', 'UM', 'UY', 'UZ', 'VA', 'VC', 'VE', 'VG', 'VI', 'VN', 'VU', 'WF', 'WS', 'YE', 'YT', 'ZA', 'ZM', 'ZW']
            index = xbmcgui.Dialog().select(heading='Choose region', list=label_list)
            if index == len(label_list) - 1:
                index = xbmcgui.Dialog().select(heading='Choose region', list=secondary_list)
                if index > -1:
                    self.add_filter('regionCode', secondary_list[index], 'Region', str(secondary_list[index]))
                    self.update()
            elif index > -1:
                self.add_filter('regionCode', label_list[index], 'Region', str(label_list[index]))
                self.update()

        @ch.click(5006)
        def set_dimension_filter(self):
            value_list = ['2d', '3d', 'any']
            label_list = ['2D', '3D', 'All']
            index = xbmcgui.Dialog().select(heading='Choose option', list=label_list)
            if index > -1:
                self.add_filter('videoDimension', value_list[index], 'Dimensions', str(label_list[index]))
                self.update()

        @ch.click(5008)
        def set_duration_filter(self):
            value_list = ['long', 'medium', 'short', 'any']
            label_list = ['Long', 'Medium', 'Short', 'All']
            index = xbmcgui.Dialog().select(heading='Choose option', list=label_list)
            if index > -1:
                self.add_filter('videoDuration', value_list[index], 'Duration', str(label_list[index]))
                self.update()

        @ch.click(5009)
        def set_caption_filter(self):
            value_list = ['closedCaption', 'none', 'any']
            label_list = ['Yes', 'No', 'All']
            index = xbmcgui.Dialog().select(heading='Subtitles', list=label_list)
            if index > -1:
                self.add_filter('videoCaption', value_list[index], 'Subtitles', str(label_list[index]))
                self.update()

        @ch.click(5012)
        def set_definition_filter(self):
            value_list = ['high', 'standard', 'any']
            label_list = ['High', 'Standard', 'All']
            index = xbmcgui.Dialog().select(heading='Resolution', list=label_list)
            if index > -1:
                self.add_filter('videoDefinition', value_list[index], 'Resolution', str(label_list[index]))
                self.update()

        @ch.click(5007)
        def toggle_type(self):
            self.filters = []
            self.page = 1
            self.mode = 'filter'
            types = {'video': 'playlist',
                     'playlist': 'channel',
                     'channel': 'video'}
            if self.type in types: self.type = types[self.type]
            if self.sort not in SORTS[self.type].keys():
                self.sort = 'relevance'
                self.sort_label = 'Relevance'
            self.update()

        def update_ui(self):
            types = {'video': 'Videos',
                     'playlist': 'Playlists',
                     'channel': 'Channels'}
            self.setProperty('Type', types[self.type])
            self.getControl(5006).setVisible(self.type == 'video')
            self.getControl(5008).setVisible(self.type == 'video')
            self.getControl(5009).setVisible(self.type == 'video')
            self.getControl(5012).setVisible(self.type == 'video')
            super(DialogYoutubeList, self).update_ui()

        def go_to_next_page(self):
            if self.page < self.total_pages:
                self.page += 1
                self.prev_page_token = self.page_token
                self.page_token = self.next_page_token

        def go_to_prev_page(self):
            if self.page > 1:
                self.page -= 1
                self.next_page_token = self.page_token
                self.page_token = self.prev_page_token

        @ch.click(5001)
        def get_sort_type(self):
            sort_key = self.type
            listitems = [key for key in SORTS[sort_key].values()]
            sort_strings = [value for value in SORTS[sort_key].keys()]
            index = xbmcgui.Dialog().select(heading='Sort by', list=listitems)
            if index == -1: return None
            self.sort = sort_strings[index]
            self.sort_label = listitems[index]
            self.update()

        @ch.action('contextmenu', 500)
        def context_menu(self):
            if self.type == 'video':
                more_vids = 'More videos from [B]%s[/B]' % self.listitem.getProperty('channel_title')
                listitems = ['Show similar videos', more_vids]
                selection = xbmcgui.Dialog().select(heading='Choose option', list=listitems)
                if selection < 0: return None
                elif selection == 0:
                    related_filter = [{'id': self.listitem.getProperty('youtube_id'),
                                       'type': 'relatedToVideoId',
                                       'typelabel': 'Related',
                                       'label': self.listitem.getLabel()}]
                    wm.open_youtube_list(filters=related_filter)
                elif selection == 1:
                    channel_filter = [{'id': self.listitem.getProperty('channel_id'),
                                       'type': 'channelId',
                                       'typelabel': 'Related',
                                       'label': self.listitem.getProperty('channel_title')}]
                    wm.open_youtube_list(filters=channel_filter)

        def add_filter(self, key, value, typelabel, label):
            super(DialogYoutubeList, self).add_filter(key=key, value=value, typelabel=typelabel, label=label, force_overwrite=True)
            self.mode = 'filter'
            self.page = 1

        def fetch_data(self, force=False):
            self.set_filter_url()
            self.set_filter_label()
            if self.search_str: self.filter_label = 'Search string: %s' % self.search_str + '  ' + self.filter_label
            else: self.filter_label = self.filter_label
            return YouTube.search_youtube(self.search_str, orderby=self.sort, extended=True, filter_str=self.filter_url, media_type=self.type, page=self.page_token)
    return DialogYoutubeList