import sys
import xbmcgui, xbmcplugin
from resources.lib import process

class Main:
    def __init__(self):
        xbmcgui.Window(10000).setProperty('extendedinfo_running', 'True')
        self._parse_argv()
        if self.infos: process.start_info_actions(self.infos, self.params)
        else:
            movies  = {
                'comingsoonmovies': 'Coming soon movies',
                'popularmovies': 'Popular movies',
                'allmovies': 'All movies'}
            tvshows = {
                'onairtvshows': 'On air tv shows',
                'populartvshows': 'Popular tv shows',
                'alltvshows': 'All tv shows'}
            library = {
                'libraryallmovies': 'Library movies',
                'libraryalltvshows': 'Library tv shows'}
            videos  = {
                'ytvideos': 'Youtube videos',
                'ytchannels': 'Youtube channels',
                'ytplaylists': 'Youtube playlists'}
            xbmcplugin.setContent(self.handle, 'files')
            media_path = 'special://home/addons/script.openinfo/resources/skins/Default/media/'
            for key, value in sorted(movies.iteritems()):
                li = xbmcgui.ListItem(value)
                li.setArt({'thumb': media_path + 'tm.png', 'fanart': media_path + 'tm-fanart.jpg'})
                url = 'plugin://script.openinfo?info=%s' % key
                xbmcplugin.addDirectoryItem(self.handle, url, li, False)
            for key, value in sorted(tvshows.iteritems()):
                li = xbmcgui.ListItem(value)
                li.setArt({'thumb': media_path + 'tm.png', 'fanart': media_path + 'tm-fanart.jpg'})
                url = 'plugin://script.openinfo?info=%s' % key
                xbmcplugin.addDirectoryItem(self.handle, url, li, False)
            for key, value in sorted(library.iteritems()):
                li = xbmcgui.ListItem(value)
                li.setArt({'thumb': media_path + 'lb.png', 'fanart': media_path + 'lb-fanart.jpg'})
                url = 'plugin://script.openinfo?info=%s' % key
                xbmcplugin.addDirectoryItem(self.handle, url, li, False)
            for key, value in sorted(videos.iteritems()):
                li = xbmcgui.ListItem(value)
                li.setArt({'thumb': media_path + 'yt.png', 'fanart': media_path + 'yt-fanart.jpg'})
                url = 'plugin://script.openinfo?info=%s' % key
                xbmcplugin.addDirectoryItem(self.handle, url, li, False)
            xbmcplugin.endOfDirectory(self.handle)
        xbmcgui.Window(10000).clearProperty('extendedinfo_running')

    def _parse_argv(self):
        args = sys.argv[2][1:]
        self.handle = int(sys.argv[1])
        self.infos = []
        self.params = {'handle': self.handle}
        if args.startswith('---'):
            delimiter = '&'
            args = args[3:]
        else: delimiter = '&&'
        for arg in args.split(delimiter):
            param = arg.replace('"', '').replace("'", " ")
            if param.startswith('info='): self.infos.append(param[5:])
            else:
                try: self.params[param.split('=')[0].lower()] = '='.join(param.split('=')[1:]).strip()
                except: pass

if (__name__ == '__main__'): Main()