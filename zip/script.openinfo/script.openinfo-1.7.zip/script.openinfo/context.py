import sys
import xbmc

def main():
    info = sys.listitem.getVideoInfoTag()
    dbid = info.getDbId()
    db_type = info.getMediaType()
    remote_id = sys.listitem.getProperty('id')
    if not dbid: dbid = sys.listitem.getProperty('dbid')
    if db_type == 'movie': xbmc.executebuiltin('RunScript(script.openinfo,info=extendedinfo,dbid=%s,id=%s,name=%s)' % (dbid, remote_id, info.getTitle()))
    elif db_type == 'tvshow': xbmc.executebuiltin('RunScript(script.openinfo,info=extendedtvinfo,dbid=%s,id=%s)' % (dbid, remote_id))
    elif db_type == 'season': xbmc.executebuiltin('RunScript(script.openinfo,info=seasoninfo,tvshow=%s,season=%s)' % (info.getTVShowTitle(), info.getSeason()))
    elif db_type == 'episode': xbmc.executebuiltin('RunScript(script.openinfo,info=extendedepisodeinfo,tvshow=%s,season=%s,episode=%s,dbid=%s)' % (info.getTVShowTitle(), info.getSeason(), info.getEpisode(), dbid))
    elif db_type in ['actor', 'director']: xbmc.executebuiltin('RunScript(script.openinfo,info=extendedactorinfo,name=%s)' % sys.listitem.getLabel())

if __name__ == '__main__': main()