import sys
import xbmc, xbmcgui, xbmcplugin
from resources.lib import process

class Main:
    def __init__(self):
        xbmc.executebuiltin('SetProperty(extendedinfo_running,True,home)')
        self._parse_argv()
        if self.infos: process.start_info_actions(self.infos, self.params)
        else:
            videos = {'ytvideos': 'yt - Youtube videos', 'ytchannels': 'yt - Youtube channels', 'ytplaylists': 'yt - Youtube playlists'}
            movies = {'comingsoonmovies': 'tm - Coming soon movies', 'popularmovies': 'tm - Popular movies', 'allmovies': 'tm - All movies'}
            tvshows = {'onairtvshows': 'tm - On air tv shows', 'populartvshows': 'tm - Popular tv shows', 'alltvshows': 'tm - All tv shows'}
            library_movies = {'libraryallmovies': 'lb - Library movies'}
            library_tvshows = {'libraryalltvshows': 'lb - Library tv shows'}
            for key, value in iter(sorted(movies.iteritems())):
                temp = {}
                temp['value'] = value
                label = temp['value'][5:]
                li = xbmcgui.ListItem(label, thumbnailImage='special://home/addons/script.openinfo/resources/skins/Default/media/tm.png')
                li.setProperty('fanart_image', 'special://home/addons/script.openinfo/resources/skins/Default/media/tm-fanart.jpg')
                url = 'plugin://script.openinfo?info=%s' %key
                xbmcplugin.addDirectoryItem(handle=self.handle, url=url, listitem=li, isFolder=True)
            for key, value in iter(sorted(tvshows.iteritems())):
                temp = {}
                temp['value'] = value
                label = temp['value'][5:]
                li = xbmcgui.ListItem(label, thumbnailImage='special://home/addons/script.openinfo/resources/skins/Default/media/tm.png')
                li.setProperty('fanart_image', 'special://home/addons/script.openinfo/resources/skins/Default/media/tm-fanart.jpg')
                url = 'plugin://script.openinfo?info=%s' %key
                xbmcplugin.addDirectoryItem(handle=self.handle, url=url, listitem=li, isFolder=True)
            for key, value in iter(sorted(library_movies.iteritems())):
                temp = {}
                temp['value'] = value
                label = temp['value'][5:]
                li = xbmcgui.ListItem(label, thumbnailImage='special://home/addons/script.openinfo/resources/skins/Default/media/lb.png')
                li.setProperty('fanart_image', 'special://home/addons/script.openinfo/resources/skins/Default/media/lb-fanart.jpg')
                url = 'plugin://script.openinfo?info=%s' %key
                xbmcplugin.addDirectoryItem(handle=self.handle, url=url, listitem=li, isFolder=True)
            for key, value in iter(sorted(library_tvshows.iteritems())):
                temp = {}
                temp['value'] = value
                label = temp['value'][5:]
                li = xbmcgui.ListItem(label, thumbnailImage='special://home/addons/script.openinfo/resources/skins/Default/media/lb.png')
                li.setProperty('fanart_image', 'special://home/addons/script.openinfo/resources/skins/Default/media/lb-fanart.jpg')
                url = 'plugin://script.openinfo?info=%s' %key
                xbmcplugin.addDirectoryItem(handle=self.handle, url=url, listitem=li, isFolder=True)
            for key, value in iter(sorted(videos.iteritems())):
                temp = {}
                temp['value'] = value
                label = temp['value'][5:]
                li = xbmcgui.ListItem(label, thumbnailImage='special://home/addons/script.openinfo/resources/skins/Default/media/yt.png')
                li.setProperty('fanart_image', 'special://home/addons/script.openinfo/resources/skins/Default/media/yt-fanart.jpg')
                url = 'plugin://script.openinfo?info=%s' %key
                xbmcplugin.addDirectoryItem(handle=self.handle, url=url, listitem=li, isFolder=True)
            xbmcplugin.endOfDirectory(self.handle)
        xbmc.executebuiltin('ClearProperty(extendedinfo_running,home)')

    def _parse_argv(self):
        args = sys.argv[2][1:]
        self.handle = int(sys.argv[1])
        self.control = 'plugin'
        self.infos = []
        self.params = {'handle': self.handle, 'control': self.control}
        if args.startswith('---'):
            delimiter = '&'
            args = args[3:]
        else: delimiter = '&&'
        for arg in args.split(delimiter):
            param = arg.replace('"', '').replace("'", ' ')
            if param.startswith('info='): self.infos.append(param[5:])
            else:
                try: self.params[param.split('=')[0].lower()] = '='.join(param.split('=')[1:]).strip()
                except: pass

if (__name__ == '__main__'): Main()