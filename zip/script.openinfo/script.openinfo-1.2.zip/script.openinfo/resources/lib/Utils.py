import os, re, time, json, urllib, urllib2, hashlib, datetime, threading, functools
import xbmc, xbmcgui, xbmcvfs, xbmcaddon, xbmcplugin

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_DATA_PATH = xbmc.translatePath("special://profile/addon_data/script.openinfo").decode("utf-8")
HOME = xbmcgui.Window(10000)
SETTING = ADDON.getSetting
include_adult = SETTING("include_adults").lower()

def after_add(type=False):
    basepath = os.path.join(ADDON_DATA_PATH, "TheMovieDB")
    path1 = os.path.join(basepath, "0ec735169a3d0b98719c987580e419e5.txt")
    path2 = os.path.join(basepath, "c36fcc8e9da1fe1a16fded10581fcc15.txt")
    if os.path.exists(path1): os.remove(path1)
    if os.path.exists(path2): os.remove(path2)
    empty_list = []
    if not type or type == "movie":
        HOME.setProperty('id_list.JSON', json.dumps(empty_list))
        HOME.setProperty('title_list.JSON', json.dumps(empty_list))
    if not type or type == "tv":
        HOME.setProperty('tvshow_id_list.JSON', json.dumps(empty_list))
        HOME.setProperty('tvshow_title_list.JSON', json.dumps(empty_list))
    force = True

def run_async(func):
    @functools.wraps(func)
    def async_func(*args, **kwargs):
        func_hl = threading.Thread(target=func, args=args, kwargs=kwargs)
        func_hl.start()
        return func_hl
    return async_func

def busy_dialog(func):
    @functools.wraps(func)
    def decorator(self, *args, **kwargs):
        xbmc.executebuiltin("ActivateWindow(busydialog)")
        result = func(self, *args, **kwargs)
        xbmc.executebuiltin("Dialog.Close(busydialog)")
        return result
    return decorator

def dictfind(lst, key, value):
    for i, dic in enumerate(lst):
        if dic[key] == value: return dic
    return ""

def format_time(time, format=None):
    try: intTime = int(time)
    except: return time
    hour = str(intTime / 60)
    minute = str(intTime %60).zfill(2)
    if format == "h": return hour
    elif format == "m": return minute
    elif intTime >= 60: return hour + " h " + minute + " min"
    else: return minute + " min"

def url_quote(input_string):
    try: return urllib.quote_plus(input_string.encode('utf8', 'ignore'))
    except: return urllib.quote_plus(unicode(input_string, "utf-8").encode("utf-8"))

def calculate_age(born, died=False):
    if died: ref_day = died.split("-")
    elif born:
        date = datetime.date.today()
        ref_day = [date.year, date.month, date.day]
    else: return ""
    actor_born = born.split("-")
    base_age = int(ref_day[0]) - int(actor_born[0])
    if len(actor_born) > 1:
        diff_months = int(ref_day[1]) - int(actor_born[1])
        diff_days = int(ref_day[2]) - int(actor_born[2])
        if diff_months < 0 or (diff_months == 0 and diff_days < 0): base_age -= 1
        elif diff_months == 0 and diff_days == 0 and not died: notify("%s (%i)" %("Birthday today!", base_age))
    return base_age

def millify(n):
    millnames = [' ', '.000', ' ' + "Million", ' ' + "Billion", ' ' + "Trillion"]
    if not n or n <= 100: return ""
    n = float(n)
    char_count = len(str(n))
    millidx = (char_count / 3) - 1
    if millidx == 3 or char_count == 9: return '%.2f%s' %(n / 10 ** (3 * millidx), millnames[millidx])
    else: return '%.0f%s' %(n / 10 ** (3 * millidx), millnames[millidx])

def media_streamdetails(filename, streamdetails):
    info = {}
    video = streamdetails['video']
    audio = streamdetails['audio']
    info['VideoCodec'] = ''
    info['VideoAspect'] = ''
    info['VideoResolution'] = ''
    info['AudioCodec'] = ''
    info['AudioChannels'] = ''
    if video:
        if (video[0]['width'] <= 720 and video[0]['height'] <= 480): info['VideoResolution'] = "480"
        elif (video[0]['width'] <= 768 and video[0]['height'] <= 576): info['VideoResolution'] = "576"
        elif (video[0]['width'] <= 960 and video[0]['height'] <= 544): info['VideoResolution'] = "540"
        elif (video[0]['width'] <= 1280 and video[0]['height'] <= 720): info['VideoResolution'] = "720"
        elif (video[0]['width'] >= 1281 or video[0]['height'] >= 721): info['VideoResolution'] = "1080"
        else: info['videoresolution'] = ""
        info['VideoCodec'] = str(video[0]['codec'])
        if (video[0]['aspect'] < 1.4859): info['VideoAspect'] = "1.33"
        elif (video[0]['aspect'] < 1.7190): info['VideoAspect'] = "1.66"
        elif (video[0]['aspect'] < 1.8147): info['VideoAspect'] = "1.78"
        elif (video[0]['aspect'] < 2.0174): info['VideoAspect'] = "1.85"
        elif (video[0]['aspect'] < 2.2738): info['VideoAspect'] = "2.20"
        else: info['VideoAspect'] = "2.35"
    elif (('dvd') in filename and not ('hddvd' or 'hd-dvd') in filename) or (filename.endswith('.vob' or '.ifo')): info['VideoResolution'] = '576'
    elif (('bluray' or 'blu-ray' or 'brrip' or 'bdrip' or 'hddvd' or 'hd-dvd') in filename): info['VideoResolution'] = '1080'
    if audio:
        info['AudioCodec'] = audio[0]['codec']
        info['AudioChannels'] = audio[0]['channels']
    return info

def fetch(dictionary, key):
    if key in dictionary:
        if dictionary[key] is not None: return dictionary[key]
    else: return ""

def get_year(year_string):
    if year_string and len(year_string) > 3: return year_string[:4]
    else: return ""

def get_http(url=None, headers=False):
    succeed = 0
    if not headers: headers = {'User-agent': 'Kodi/18.0 ( phil65@kodi.tv )'}
    request = urllib2.Request(url)
    for (key, value) in headers.iteritems(): request.add_header(key, value)
    while (succeed < 2) and (not xbmc.abortRequested):
        try:
            response = urllib2.urlopen(request, timeout=3)
            data = response.read()
            return data
        except:
            log("get_http: could not get data from %s" %url)
            xbmc.sleep(500)
            succeed += 1
    return None

def get_JSON_response(url="", cache_days=7.0, folder=False, headers=False):
    now = time.time()
    hashed_url = hashlib.md5(url).hexdigest()
    if folder: cache_path = xbmc.translatePath(os.path.join(ADDON_DATA_PATH, folder))
    else: cache_path = xbmc.translatePath(os.path.join(ADDON_DATA_PATH))
    path = os.path.join(cache_path, hashed_url + ".txt")
    cache_seconds = int(cache_days * 86400.0)
    prop_time = HOME.getProperty(hashed_url + "_timestamp")
    if prop_time and now - float(prop_time) < cache_seconds:
        try:
            prop = json.loads(HOME.getProperty(hashed_url))
            log("prop load for %s. time: %f" %(url, time.time() - now))
            if prop: return prop
        except: log("could not load prop data for %s" %url)
    if xbmcvfs.exists(path) and ((now - os.path.getmtime(path)) < cache_seconds):
        results = read_from_file(path)
        log("loaded file for %s. time: %f" %(url, time.time() - now))
    else:
        response = get_http(url, headers)
        try:
            results = json.loads(response)
            log("download %s. time: %f" %(url, time.time() - now))
            save_to_file(results, hashed_url, cache_path)
        except:
            log("Exception: Could not get new JSON data from %s. Tryin to fallback to cache" %url)
            log(response)
            if xbmcvfs.exists(path): results = read_from_file(path)
            else: results = []
    if results:
        HOME.setProperty(hashed_url + "_timestamp", str(now))
        HOME.setProperty(hashed_url, json.dumps(results))
        return results
    else: return []

class GetFileThread(threading.Thread):
    def __init__(self, url):
        threading.Thread.__init__(self)
        self.url = url

    def run(self):
        self.file = get_file(self.url)

def get_file(url):
    clean_url = xbmc.translatePath(urllib.unquote(url)).replace("image://", "")
    if clean_url.endswith("/"): clean_url = clean_url[:-1]
    cached_thumb = xbmc.getCacheThumbName(clean_url)
    vid_cache_file = os.path.join("special://profile/Thumbnails/Video", cached_thumb[0], cached_thumb)
    cache_file_jpg = os.path.join("special://profile/Thumbnails/", cached_thumb[0], cached_thumb[:-4] + ".jpg").replace("\\", "/")
    cache_file_png = cache_file_jpg[:-4] + ".png"
    if xbmcvfs.exists(cache_file_jpg):
        log("cache_file_jpg Image: " + url + "-->" + cache_file_jpg)
        return xbmc.translatePath(cache_file_jpg)
    elif xbmcvfs.exists(cache_file_png):
        log("cache_file_png Image: " + url + "-->" + cache_file_png)
        return cache_file_png
    elif xbmcvfs.exists(vid_cache_file):
        log("vid_cache_file Image: " + url + "-->" + vid_cache_file)
        return vid_cache_file
    try:
        request = urllib2.Request(url)
        request.add_header('Accept-encoding', 'gzip')
        response = urllib2.urlopen(request, timeout=3)
        data = response.read()
        response.close()
        log('image downloaded: ' + url)
    except:
        log('image download failed: ' + url)
        return ""
    if not data: return ""
    if url.endswith(".png"): image = cache_file_png
    else: image = cache_file_jpg
    try:
        with open(xbmc.translatePath(image), "wb") as f: f.write(data)
        return xbmc.translatePath(image)
    except:
        log('failed to save image ' + url)
        return ""

def log(txt):
    if isinstance(txt, str): txt = txt.decode("utf-8", 'ignore')
    message = u'%s: %s' %(ADDON_ID, txt)
    xbmc.log(msg=message.encode("utf-8", 'ignore'), level=xbmc.LOGDEBUG)

def get_browse_dialog(default="", heading="Browse", dlg_type=3, shares="files", mask="", use_thumbs=False, treat_as_folder=False):
    dialog = xbmcgui.Dialog()
    value = dialog.browse(dlg_type, heading, shares, mask, use_thumbs, treat_as_folder, default)
    return value

def save_to_file(content, filename, path=""):
    if path == "": text_file_path = get_browse_dialog() + filename + ".txt"
    else:
        if not xbmcvfs.exists(path): xbmcvfs.mkdirs(path)
        text_file_path = os.path.join(path, filename + ".txt")
    now = time.time()
    text_file = xbmcvfs.File(text_file_path, "w")
    json.dump(content, text_file)
    text_file.close()
    log("saved textfile %s. Time: %f" %(text_file_path, time.time() - now))
    return True

def read_from_file(path="", raw=False):
    if path == "": path = get_browse_dialog(dlg_type=1)
    if not xbmcvfs.exists(path): return False
    try:
        with open(path) as f:
            log("opened textfile %s." %(path))
            if not raw: result = json.load(f)
            else: result = f.read()
        return result
    except:
        log("failed to load textfile: " + path)
        return False

def notify(header="", message="", icon=ADDON.getAddonInfo('icon'), time=5000, sound=True):
    xbmcgui.Dialog().notification(heading=header, message=message, icon=icon, time=time, sound=sound)

def get_kodi_json(method, params):
    json_query = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "%s", "params": %s, "id": 1}' %(method, params))
    json_query = unicode(json_query, 'utf-8', errors='ignore')
    return json.loads(json_query)

def pass_dict_to_skin(data=None, prefix="", debug=False, precache=False, window_id=10000):
    window = xbmcgui.Window(window_id)
    if not data: return None
    threads = []
    image_requests = []
    for (key, value) in data.iteritems():
        if not value: continue
        value = unicode(value)
        if precache:
            if value.startswith("http") and (value.endswith(".jpg") or value.endswith(".png")):
                if value not in image_requests and value:
                    thread = GetFileThread(value)
                    threads += [thread]
                    thread.start()
                    image_requests.append(value)
        window.setProperty('%s%s' %(prefix, str(key)), value)
        if debug: log('%s%s' %(prefix, str(key)) + value)
    for x in threads: x.join()

def merge_dict_lists(items, key="job"):
    crew_id_list = []
    crew_list = []
    for item in items:
        if item["id"] not in crew_id_list:
            crew_id_list.append(item["id"])
            crew_list.append(item)
        else:
            index = crew_id_list.index(item["id"])
            if key in crew_list[index]: crew_list[index][key] = crew_list[index][key] + " / " + item[key]
    return crew_list

def pass_list_to_skin(name="", data=[], prefix="", handle=None, limit=False):
    if data and limit and int(limit) < len(data): data = data[:int(limit)]
    if not handle:
        set_window_props(name, data, prefix)
        return None
    HOME.clearProperty(name)
    if data:
        HOME.setProperty(name + ".Count", str(len(data)))
        items = create_listitems(data)
        itemlist = [(item.getProperty("path"), item, bool(item.getProperty("directory"))) for item in items]
        xbmcplugin.addDirectoryItems(handle=handle, items=itemlist, totalItems=len(itemlist))
    xbmcplugin.endOfDirectory(handle)

def set_window_props(name, data, prefix="", debug=False):
    if not data:
        HOME.setProperty('%s%s.Count' %(prefix, name), '0')
        log("%s%s.Count = None" %(prefix, name))
        return None
    for (count, result) in enumerate(data):
        if debug: log("%s%s.%i = %s" %(prefix, name, count + 1, str(result)))
        for (key, value) in result.iteritems():
            value = unicode(value)
            HOME.setProperty('%s%s.%i.%s' %(prefix, name, count + 1, str(key)), value)
            if key.lower() in ["poster", "banner", "fanart", "clearart", "clearlogo", "landscape", "discart", "characterart", "tvshow.fanart", "tvshow.poster",
                               "tvshow.banner", "tvshow.clearart", "tvshow.characterart"]: HOME.setProperty('%s%s.%i.Art(%s)' %(prefix, name, count + 1, str(key)), value)
            if debug: log('%s%s.%i.%s --> ' %(prefix, name, count + 1, str(key)) + value)
    HOME.setProperty('%s%s.Count' %(prefix, name), str(len(data)))

def create_listitems(data=None, preload_images=0):
    INT_INFOLABELS = ["year", "episode", "season", "top250", "tracknumber", "playcount", "overlay"]
    FLOAT_INFOLABELS = ["rating"]
    STRING_INFOLABELS = ["genre", "director", "mpaa", "plot", "plotoutline", "title", "originaltitle", "sorttitle", "duration", "studio", "tagline",
                         "writer", "tvshowtitle", "premiered", "status", "code", "aired", "credits", "lastplayed", "album", "votes", "trailer", "dateadded"]
    if not data: return []
    itemlist = []
    threads = []
    image_requests = []
    for (count, result) in enumerate(data):
        listitem = xbmcgui.ListItem('%s' %(str(count)))
        for (key, value) in result.iteritems():
            if not value: continue
            value = unicode(value)
            if count < preload_images:
                if value.startswith("http://") and (value.endswith(".jpg") or value.endswith(".png")):
                    if value not in image_requests:
                        thread = GetFileThread(value)
                        threads += [thread]
                        thread.start()
                        image_requests.append(value)
            if key.lower() in ["name", "label"]: listitem.setLabel(value)
            elif key.lower() in ["label2"]: listitem.setLabel2(value)
            elif key.lower() in ["title"]:
                listitem.setLabel(value)
                listitem.setInfo('video', {key.lower(): value})
            elif key.lower() in ["thumb"]:
                listitem.setThumbnailImage(value)
                listitem.setArt({key.lower(): value})
            elif key.lower() in ["icon"]:
                listitem.setIconImage(value)
                listitem.setArt({key.lower(): value})
            elif key.lower() in ["path"]: listitem.setPath(path=value)
            elif key.lower() in ["poster", "banner", "fanart", "clearart", "clearlogo", "landscape", "discart", "characterart", "tvshow.fanart",
                                 "tvshow.poster", "tvshow.banner", "tvshow.clearart", "tvshow.characterart"]: listitem.setArt({key.lower(): value})
            elif key.lower() in INT_INFOLABELS:
                try: listitem.setInfo('video', {key.lower(): int(value)})
                except: pass
            elif key.lower() in STRING_INFOLABELS: listitem.setInfo('video', {key.lower(): value})
            elif key.lower() in FLOAT_INFOLABELS:
                try: listitem.setInfo('video', {key.lower(): "%1.1f" %float(value)})
                except: pass
            listitem.setProperty('%s' %(key), value)
        listitem.setProperty("index", str(count))
        itemlist.append(listitem)
    for x in threads: x.join()
    return itemlist

def clean_text(text):
    if not text: return ""
    text = re.sub('(From Wikipedia, the free encyclopedia)|(Description above from the Wikipedia.*?Wikipedia)', '', text)
    text = re.sub('<(.|\n|\r)*?>', '', text)
    text = text.replace('<br \/>', '[CR]')
    text = text.replace('<em>', '[I]').replace('</em>', '[/I]')
    text = text.replace('&amp;', '&')
    text = text.replace('&gt;', '>').replace('&lt;', '<')
    text = text.replace('&#39;', "'").replace('&quot;', '"')
    text = re.sub("\n\\.$", "", text)
    text = text.replace('User-contributed text is available under the Creative Commons By-SA License and may also be available under the GNU FDL.', '')
    while text:
        s = text[0]
        e = text[-1]
        if s in [u'\u200b', " ", "\n"]: text = text[1:]
        elif e in [u'\u200b', " ", "\n"]: text = text[:-1]
        elif s.startswith(".") and not s.startswith(".."): text = text[1:]
        else: break
    return text.strip()