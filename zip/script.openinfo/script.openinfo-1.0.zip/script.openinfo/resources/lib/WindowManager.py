import xbmc
import xbmcgui
import xbmcaddon
from resources.lib import Utils
from resources.lib import local_db
import TheMovieDB

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_PATH = ADDON.getAddonInfo('path').decode("utf-8")
LIST_DIALOG_FILE = u'%s-VideoList.xml' %(ADDON_ID)
ACTOR_DIALOG_FILE = u'%s-DialogInfo.xml' %(ADDON_ID)
INFO_DIALOG_FILE = u'%s-DialogVideoInfo.xml' %(ADDON_ID)
SETTING = ADDON.getSetting
COLORMAIN = SETTING("colormain")

class WindowManager(object):
    window_stack = []
    def __init__(self):
        self.reopen_window = False

    def add_to_stack(self, window):
        self.window_stack.append(window)

    def pop_stack(self):
        if self.window_stack:
            dialog = self.window_stack.pop()
            xbmc.sleep(300)
            dialog.doModal()
        elif self.reopen_window:
            xbmc.sleep(500)
            xbmc.executebuiltin("Action(Info)")

    def open_movie_info(self, prev_window=None, movie_id=None, dbid=None, name=None, imdb_id=None):
        xbmc.executebuiltin("ActivateWindow(busydialog)")
        from resources.lib.DialogVideoInfo import get_movie_window
        if not movie_id: movie_id = TheMovieDB.get_movie_tmdb_id(imdb_id=imdb_id, dbid=dbid, name=name)
        movieclass = get_movie_window(DialogXML)
        dialog = movieclass(INFO_DIALOG_FILE, ADDON_PATH, id=movie_id, dbid=dbid)
        xbmc.executebuiltin("Dialog.Close(busydialog)")
        self.open_dialog(dialog, prev_window)

    def open_tvshow_info(self, prev_window=None, tvshow_id=None, dbid=None, tvdb_id=None, imdb_id=None, name=None):
        xbmc.executebuiltin("ActivateWindow(busydialog)")
        from resources.lib.DialogTVShowInfo import get_tvshow_window
        tmdb_id = None
        if tvshow_id: tmdb_id = tvshow_id
        elif tvdb_id: tmdb_id = TheMovieDB.get_show_tmdb_id(tvdb_id)
        elif imdb_id: tmdb_id = TheMovieDB.get_show_tmdb_id(tvdb_id=imdb_id, source="imdb_id")
        elif dbid and (int(dbid) > 0):
            tvdb_id = local_db.get_imdb_id_from_db(media_type="tvshow", dbid=dbid)
            if tvdb_id: tmdb_id = TheMovieDB.get_show_tmdb_id(tvdb_id)
        elif name: tmdb_id = TheMovieDB.search_media(media_name=name, year="", media_type="tv")
        tvshow_class = get_tvshow_window(DialogXML)
        dialog = tvshow_class(INFO_DIALOG_FILE, ADDON_PATH, tmdb_id=tmdb_id, dbid=dbid)
        xbmc.executebuiltin("Dialog.Close(busydialog)")
        self.open_dialog(dialog, prev_window)

    def open_season_info(self, prev_window=None, tvshow_id=None, season=None, tvshow=None, dbid=None):
        xbmc.executebuiltin("ActivateWindow(busydialog)")
        from resources.lib.DialogSeasonInfo import get_season_window
        if not tvshow_id:
            response = TheMovieDB.get_tmdb_data("search/tv?query=%s&language=%s&" %(Utils.url_quote(tvshow), SETTING("LanguageID")), 30)
            if response["results"]: tvshow_id = str(response['results'][0]['id'])
            else:
                tvshow = re.sub('\(.*?\)', '', tvshow)
                response = TheMovieDB.get_tmdb_data("search/tv?query=%s&language=%s&" %(Utils.url_quote(tvshow), SETTING("LanguageID")), 30)
                if response["results"]: tvshow_id = str(response['results'][0]['id'])
        season_class = get_season_window(DialogXML)
        dialog = season_class(INFO_DIALOG_FILE, ADDON_PATH, id=tvshow_id, season=season, dbid=dbid)
        xbmc.executebuiltin("Dialog.Close(busydialog)")
        self.open_dialog(dialog, prev_window)

    def open_episode_info(self, prev_window=None, tvshow_id=None, season=None, episode=None, tvshow=None, dbid=None):
        from resources.lib.DialogEpisodeInfo import get_episode_window
        ep_class = get_episode_window(DialogXML)
        if not tvshow_id and tvshow:
            from urllib import quote_plus
            response = TheMovieDB.get_tmdb_data("search/tv?query=%s&language=%s&" %(quote_plus(tvshow), SETTING("LanguageID")), 30)
            if response["results"]: tvshow_id = str(response['results'][0]['id'])
        dialog = ep_class(INFO_DIALOG_FILE, ADDON_PATH, show_id=tvshow_id, season=season, episode=episode, dbid=dbid)
        self.open_dialog(dialog, prev_window)

    def open_actor_info(self, prev_window=None, actor_id=None, name=None):
        from resources.lib.DialogActorInfo import get_actor_window
        if not actor_id:
            name = name.decode("utf-8").split(" " + "as" + " ")
            names = name[0].strip().split(" / ")
            if len(names) > 1:
                ret = xbmcgui.Dialog().select(heading=Utils.LANG(32027), list=names)
                if ret == -1: return None
                name = names[ret]
            else: name = names[0]
            xbmc.executebuiltin("ActivateWindow(busydialog)")
            actor_info = TheMovieDB.get_person_info(name)
            if actor_info: actor_id = actor_info["id"]
        else: xbmc.executebuiltin("ActivateWindow(busydialog)")
        actor_class = get_actor_window(DialogXML)
        dialog = actor_class(ACTOR_DIALOG_FILE, ADDON_PATH, id=actor_id)
        xbmc.executebuiltin("Dialog.Close(busydialog)")
        self.open_dialog(dialog, prev_window)

    def open_video_list(self, prev_window=None, listitems=None, filters=[], mode="filter", list_id=False, filter_label="", media_type="movie", search_str=""):
        from resources.lib.DialogVideoList import get_tmdb_window
        if prev_window:
            try: color = prev_window.data["general"]['ImageColor']
            except: color = COLORMAIN
        else: color = COLORMAIN
        browser_class = get_tmdb_window(DialogXML)
        dialog = browser_class(LIST_DIALOG_FILE, ADDON_PATH, listitems=listitems, color=color, filters=filters, mode=mode, list_id=list_id, filter_label=filter_label, type=media_type, search_str=search_str)
        if prev_window:
            self.add_to_stack(prev_window)
            prev_window.close()
        dialog.doModal()

    def open_youtube_list(self, prev_window=None, search_str="", filters=[], sort="relevance", filter_label="", media_type="video"):
        from resources.lib.DialogYoutubeList import get_youtube_window
        if prev_window:
            try: color = prev_window.data["general"]['ImageColor']
            except: color = COLORMAIN
        else: color = COLORMAIN
        youtube_class = get_youtube_window(DialogXML)
        dialog = youtube_class(u'%s-YoutubeList.xml' %ADDON_ID, ADDON_PATH, search_str=search_str, color=color, filters=filters, filter_label=filter_label, type=media_type)
        if prev_window:
            self.add_to_stack(prev_window)
            prev_window.close()
        dialog.doModal()

    def open_slideshow(self, listitems, index):
        dialog = SlideShow(u'%s-SlideShow.xml' %ADDON_ID, ADDON_PATH, listitems=listitems, index=index)
        dialog.doModal()
        return dialog.position

    def open_textviewer(self, header="", text="", color="FFFFFFFF"):
        w = TextViewerDialog('DialogTextViewer.xml', ADDON_PATH, header=header, text=text, color=color)
        w.doModal()

    def open_selectdialog(self, listitems):
        w = SelectDialog('DialogSelect.xml', ADDON_PATH, listing=listitems)
        w.doModal()
        return w.listitem, w.index

    def open_dialog(self, dialog, prev_window):
        if dialog.data:
            if xbmc.getCondVisibility("Window.IsVisible(movieinformation)"):
                xbmc.executebuiltin("Dialog.Close(movieinformation)")
                self.reopen_window = True
            if prev_window:
                self.add_to_stack(prev_window)
                prev_window.close()
            dialog.doModal()
        else: return False
wm = WindowManager()

class DialogXML(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        xbmcgui.WindowXMLDialog.__init__(self)
        self.window_type = "dialog"

    def onInit(self):
        self.window_id = xbmcgui.getCurrentWindowDialogId()
        self.window = xbmcgui.Window(self.window_id)

class TextViewerDialog(xbmcgui.WindowXMLDialog):
    ACTION_PREVIOUS_MENU = [9, 92, 10]
    def __init__(self, *args, **kwargs):
        xbmcgui.WindowXMLDialog.__init__(self)
        self.text = kwargs.get('text')
        self.header = kwargs.get('header')
        self.color = kwargs.get('color')

    def onInit(self):
        window_id = xbmcgui.getCurrentWindowDialogId()
        xbmcgui.Window(window_id).setProperty("WindowColor", self.color)
        self.getControl(1).setLabel(self.header)
        self.getControl(5).setText(self.text)

    def onAction(self, action):
        if action in self.ACTION_PREVIOUS_MENU: self.close()

    def onClick(self, control_id):
        pass

    def onFocus(self, control_id):
        pass

class SlideShow(DialogXML):
    ACTION_PREVIOUS_MENU = [9, 92, 10]
    def __init__(self, *args, **kwargs):
        self.imagelist = kwargs.get('listitems')
        self.index = kwargs.get('index')
        self.image = kwargs.get('image')
        self.action = None

    def onInit(self):
        super(SlideShow, self).onInit()
        if self.imagelist:
            self.getControl(10001).addItems(Utils.create_listitems(self.imagelist))
            self.getControl(10001).selectItem(self.index)
            self.setFocusId(10001)
            xbmc.executebuiltin("SetFocus(10001)")

    def onAction(self, action):
        if action in self.ACTION_PREVIOUS_MENU:
            self.position = self.getControl(10001).getSelectedPosition()
            self.close()

class SelectDialog(xbmcgui.WindowXMLDialog):
    ACTION_PREVIOUS_MENU = [9, 92, 10]
    @Utils.busy_dialog
    def __init__(self, *args, **kwargs):
        xbmcgui.WindowXMLDialog.__init__(self)
        self.items = kwargs.get('listing')
        self.listitems = Utils.create_listitems(self.items)
        self.listitem = None
        self.index = -1

    def onInit(self):
        self.list = self.getControl(6)
        self.getControl(3).setVisible(False)
        self.getControl(5).setVisible(False)
        self.getControl(1).setLabel(Utils.LANG(32151))
        self.list.addItems(self.listitems)
        self.setFocus(self.list)

    def onAction(self, action):
        if action in self.ACTION_PREVIOUS_MENU: self.close()

    def onClick(self, control_id):
        if control_id == 6 or control_id == 3:
            self.index = int(self.list.getSelectedItem().getProperty("index"))
            self.listitem = self.items[self.index]
            self.close()

    def onFocus(self, control_id):
        pass