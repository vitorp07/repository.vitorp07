import sys
import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin
from resources.lib import process

ADDON = xbmcaddon.Addon()
SETTING = ADDON.getSetting
COLORMAIN = SETTING("colormain")
COLORTHEMED = SETTING("colorthemed")
ADDON_PATH = ADDON.getAddonInfo('path').decode("utf-8")

class Main:
    def __init__(self):
        xbmc.executebuiltin('SetProperty(extendedinfo_running,True,home)')
        if xbmc.getCondVisibility('Skin.String(WindowColorMain,'+COLORMAIN+')') == False: xbmc.executebuiltin('Skin.SetString(WindowColorMain,'+COLORMAIN+')')
        elif xbmc.getCondVisibility('Skin.String(WindowColorThemed,'+COLORTHEMED+')') == False: xbmc.executebuiltin('Skin.SetString(WindowColorThemed,'+COLORTHEMED+')')
        self._parse_argv()
        if self.infos: process.start_info_actions(self.infos, self.params)
        else:
            videos = {"ytvideos": "yt - Youtube videos", "ytchannels": "yt - Youtube channels", "ytplaylists": "yt - Youtube playlists"}
            movies = {"comingsoonmovies": "tm - Coming soon movies", "popularmovies": "tm - Popular movies", "allmovies": "tm - All movies"}
            tvshows = {"onairtvshows": "tm - On air tv shows", "populartvshows": "tm - Popular tv shows", "alltvshows": "tm - All tv shows"}
            library_movies = {"libraryallmovies": "lb - Library movies"}
            library_tvshows = {"libraryalltvshows": "lb - Library tv shows"}
            xbmcplugin.setContent(self.handle, 'videos')
            movie_items = movies
            tvshow_items = tvshows
            lib_movie_items = library_movies
            lib_tvshow_items = library_tvshows
            youtube_items = videos
            for key, value in iter(sorted(movie_items.iteritems())):
                temp = {}
                temp['value'] = value
                image_code = temp['value'][:2]
                label = temp['value'][5:]
                li = xbmcgui.ListItem(label, iconImage="%s/resources/skins/Default/media/%s.png" %(ADDON_PATH, image_code), thumbnailImage="%s/resources/skins/Default/media/%s.png" %(ADDON_PATH, image_code))
                li.setProperty('fanart_image', "special://home/addons/script.openinfo/resources/skins/Default/media/%s-fanart.jpg" %image_code)
                url = 'plugin://script.openinfo?info=%s' %key
                xbmcplugin.addDirectoryItem(handle=self.handle, url=url, listitem=li, isFolder=True)
            for key, value in iter(sorted(tvshow_items.iteritems())):
                temp = {}
                temp['value'] = value
                image_code = temp['value'][:2]
                label = temp['value'][5:]
                li = xbmcgui.ListItem(label, iconImage="%s/resources/skins/Default/media/%s.png" %(ADDON_PATH, image_code), thumbnailImage="%s/resources/skins/Default/media/%s.png" %(ADDON_PATH, image_code))
                li.setProperty('fanart_image', "special://home/addons/script.openinfo/resources/skins/Default/media/%s-fanart.jpg" %image_code)
                url = 'plugin://script.openinfo?info=%s' %key
                xbmcplugin.addDirectoryItem(handle=self.handle, url=url, listitem=li, isFolder=True)
            for key, value in iter(sorted(lib_movie_items.iteritems())):
                temp = {}
                temp['value'] = value
                image_code = temp['value'][:2]
                label = temp['value'][5:]
                li = xbmcgui.ListItem(label, iconImage="%s/resources/skins/Default/media/%s.png" %(ADDON_PATH, image_code), thumbnailImage="%s/resources/skins/Default/media/%s.png" %(ADDON_PATH, image_code))
                li.setProperty('fanart_image', "special://home/addons/script.openinfo/resources/skins/Default/media/%s-fanart.jpg" %image_code)
                url = 'plugin://script.openinfo?info=%s' %key
                xbmcplugin.addDirectoryItem(handle=self.handle, url=url, listitem=li, isFolder=True)
            for key, value in iter(sorted(lib_tvshow_items.iteritems())):
                temp = {}
                temp['value'] = value
                image_code = temp['value'][:2]
                label = temp['value'][5:]
                li = xbmcgui.ListItem(label, iconImage="%s/resources/skins/Default/media/%s.png" %(ADDON_PATH, image_code), thumbnailImage="%s/resources/skins/Default/media/%s.png" %(ADDON_PATH, image_code))
                li.setProperty('fanart_image', "special://home/addons/script.openinfo/resources/skins/Default/media/%s-fanart.jpg" %image_code)
                url = 'plugin://script.openinfo?info=%s' %key
                xbmcplugin.addDirectoryItem(handle=self.handle, url=url, listitem=li, isFolder=True)
            for key, value in iter(sorted(youtube_items.iteritems())):
                temp = {}
                temp['value'] = value
                image_code = temp['value'][:2]
                label = temp['value'][5:]
                li = xbmcgui.ListItem(label, iconImage="%s/resources/skins/Default/media/%s.png" %(ADDON_PATH, image_code), thumbnailImage="%s/resources/skins/Default/media/%s.png" %(ADDON_PATH, image_code))
                li.setProperty('fanart_image', "special://home/addons/script.openinfo/resources/skins/Default/media/%s-fanart.jpg" %image_code)
                url = 'plugin://script.openinfo?info=%s' %key
                xbmcplugin.addDirectoryItem(handle=self.handle, url=url, listitem=li, isFolder=True)
            xbmcplugin.endOfDirectory(self.handle)
        xbmc.executebuiltin('ClearProperty(extendedinfo_running,home)')

    def _parse_argv(self):
        args = sys.argv[2][1:]
        self.handle = int(sys.argv[1])
        self.control = "plugin"
        self.infos = []
        self.params = {"handle": self.handle, "control": self.control}
        if args.startswith("---"):
            delimiter = "&"
            args = args[3:]
        else: delimiter = "&&"
        for arg in args.split(delimiter):
            param = arg.replace('"', '').replace("'", " ")
            if param.startswith('info='): self.infos.append(param[5:])
            else:
                try: self.params[param.split("=")[0].lower()] = "=".join(param.split("=")[1:]).strip()
                except: pass

if (__name__ == "__main__"): Main()