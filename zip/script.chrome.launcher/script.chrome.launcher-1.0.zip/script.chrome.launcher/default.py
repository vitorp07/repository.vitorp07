import xbmc, os, xbmcaddon, subprocess

addon = xbmcaddon.Addon()
script_path = addon.getAddonInfo('path')
script_file = 'chromelauncher.bat'
script = os.path.join(script_path, script_file)
subprocess.Popen(script, shell=True, close_fds=True)