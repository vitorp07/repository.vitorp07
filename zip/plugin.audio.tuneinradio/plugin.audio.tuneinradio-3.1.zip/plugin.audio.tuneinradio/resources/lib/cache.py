import os

class Cache:
    def __init__(self, path, filename, max=None):
        if not os.path.exists(path): os.makedirs(path)
        self.cachedb = os.path.join(path, filename)
        self.max = max

    def add(self, item, field=None):
        cache = self.get()
        if cache.count(item) > 0: return False
        if field is not None:
            for row in cache:
                if row[field] == item[field]: return False
        if self.max and len(cache) >= self.max: cache.pop(0)
        cache.append(item)
        file(self.cachedb, 'w').write(repr(cache))
        return True

    def get(self):
        if os.path.isfile(self.cachedb): return eval(file(self.cachedb, 'r').read())
        return []

    def remove(self, item):
        cache = self.get()
        if cache.count(item) == 0: return
        cache.remove(item)
        file(self.cachedb, 'w').write(repr(cache))
        return

    def len(self):
        cache = self.get()
        return len(cache)

    def clear(self):
        cache = []
        file(self.cachedb, 'w').write(repr(cache))
        return

    def lastupdate(self):
        if os.path.isfile(self.cachedb):
            from time import time
            return time() - os.path.getmtime(self.cachedb)
        return None