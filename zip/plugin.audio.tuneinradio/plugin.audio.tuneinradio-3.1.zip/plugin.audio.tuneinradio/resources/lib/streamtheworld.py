import urllib2
import xml.dom.minidom as minidom

class StreamTheWorld:
    def __init__(self, cs):
        self.__cs__ = cs
        return

    def __validate_callsign(self, cs, acc=True):
        if not cs or not isinstance(cs, str): raise ValueError('callsign \'%s\' is not a string.' %cs)
        if len(cs) < 6: raise ValueError('callsign \'%s\' is too short.' %cs)
        if acc and not cs.endswith('AAC'): cs = cs + 'AAC'
        return cs

    def __make_request(self, callsign):
        host = 'playerservices.streamtheworld.com'
        req = urllib2.Request('http://%s/api/livestream?version=1.5&mount=%s&lang=en' %(host, callsign))
        req.add_header('User-Agent', 'Mozilla/5.0')
        return req

    def __t(self, element):
        return element.firstChild.data

    def __check_status(self, ele):
        status = ele.getElementsByTagName('status')[0]
        if self.__t(status.getElementsByTagName('status-code')[0]) != '200':
            msg = self.__t(status.getElementsByTagName('status-message')[0])
            raise Exception('Error locating stream: ' + msg)

    def __create_stream_urls(self, srcfile):
        doc = minidom.parse(srcfile)
        mp = doc.getElementsByTagName('mountpoint')[0]
        self.__check_status(mp)
        mt = self.__t(mp.getElementsByTagName('mount')[0])
        allurls = []
        for s in mp.getElementsByTagName('server'):
            ip = self.__t(s.getElementsByTagName('ip')[0])
            ports = [self.__t(p) for p in s.getElementsByTagName('port')]
            urls = ['http://%s:%s/%s' %(ip, p, mt) for p in ports]
            allurls.extend(urls)
        return allurls

    def get_stream_url(self, cs):
        try:
            callsign = self.__validate_callsign(cs)
            req = self.__make_request(callsign)
            result = urllib2.urlopen(req)
            urls = self.__create_stream_urls(result)
        except:
            callsign = self.__validate_callsign(cs, False)
            req = self.__make_request(callsign)
            result = urllib2.urlopen(req)
            urls = self.__create_stream_urls(result)
        if len(urls) > 0:
            from random import choice
            u = choice(urls)
            if not u.endswith('_SC'): u = u + '_SC'
            return u