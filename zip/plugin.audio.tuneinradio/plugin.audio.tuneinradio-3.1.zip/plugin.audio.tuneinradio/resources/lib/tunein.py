import os
import re
import json
import urllib
import urllib2
import ConfigParser
import xml.dom.minidom as minidom

class TuneIn:
    class TuneInError(Exception):
        def __init__(self, status, fault, faultcode=''):
            self.status = status
            self.fault = fault
            self.faultcode = faultcode

        def __str__(self):
            return repr(self.status)
            return repr(self.fault)
            return repr(self.faultcode)

    def log_debug(self, msg):
        if self._debug is True: print 'TuneIn Library: DEBUG: %s' %msg

    def __init__(self, partnerid, serial=None, locale="en-GB", formats=None, debug=False):
        self._global_params = []
        self._global_params.append({'param': 'partnerId', 'value': partnerid})
        if serial is not None: self._global_params.append({'param': 'serial', 'value': serial})
        self._global_params.append({'param': 'render', 'value': 'json'})
        self._global_params.append({'param': 'locale', 'value': locale})
        if (formats is not None): self._global_params.append({'param': 'formats', 'value': formats})
        self._debug = debug
        self.log_debug('Global Params: %s' %self._global_params)

    def __add_params_to_url(self, method, fnparams=None, addrender=True, addserial=True):
        params = {}
        for param in self._global_params:
            if (param['param'] == 'render' and addrender is False): pass
            elif (param['param'] == 'serial' and addserial is False): pass
            elif (param['value']): params[param['param']] = param['value']
        for param in fnparams:
            if (param['value']): params[param['param']] = param['value']
        url = 'https://opml.radiotime.com/%s?%s' %(method, urllib.urlencode(params))
        self.log_debug('URL: %s' %url)
        return url

    def __call_tunein(self, method, params=None):
        url = self.__add_params_to_url(method, params)
        req = urllib2.Request(url)
        f = urllib2.urlopen(req)
        result = json.load(f)
        f.close()
        return result

    def __parse_asf(self, url):
        self.log_debug('__parse_asf')
        self.log_debug('url: %s' %url)
        streams = []
        req = urllib2.Request(url)
        f = urllib2.urlopen(req)
        config = ConfigParser.RawConfigParser()
        config.readfp(f)
        references = config.items('Reference')
        for ref in references: streams.append(ref[1])
        f.close()
        return streams

    def __parse_asx(self, url):
        self.log_debug('__parse_asx')
        self.log_debug('url: %s' % url)
        streams = []
        req = urllib2.Request(url)
        f = urllib2.urlopen(req)
        xmlstr = f.read().decode('ascii', 'ignore')
        dom = minidom.parseString(xmlstr)
        asx = dom.childNodes[0]
        for node in asx.childNodes:
            if (str(node.localName).lower() == 'entryref' and node.hasAttribute('href')): streams.append(node.getAttribute('href'))
            elif (str(node.localName).lower() == 'entryref' and node.hasAttribute('HREF')): streams.append(node.getAttribute('HREF'))
            elif (str(node.localName).lower() == 'entry'):
                for subnode in node.childNodes:
                    if (str(subnode.localName).lower() == 'ref' and subnode.hasAttribute('href') and not subnode.getAttribute('href') in streams): streams.append(subnode.getAttribute('href'))
                    elif (str(subnode.localName).lower() == 'ref' and subnode.hasAttribute('HREF') and not subnode.getAttribute('HREF') in streams): streams.append(subnode.getAttribute('HREF'))
        f.close()
        return streams

    def __parse_m3u(self, url):
        self.log_debug('__parse_m3u')
        self.log_debug('url: %s' %url)
        streams = []
        req = urllib2.Request(url)
        f = urllib2.urlopen(req)
        for line in f:
            if len(line.strip()) > 0 and not line.strip().startswith('#'): streams.append(line.strip())
        f.close()
        return streams

    def __parse_pls(self, url):
        self.log_debug('__parse_pls')
        self.log_debug('url: %s' %url)
        streams = []
        req = urllib2.Request(url)
        f = urllib2.urlopen(req)
        config = ConfigParser.RawConfigParser()
        config.readfp(f)
        numentries = config.getint('playlist', 'NumberOfEntries')
        while (numentries > 0):
            streams.append(config.get('playlist', 'File' + str(numentries)))
            numentries -= 1
        f.close()
        return streams

    def __result_ok(self, result):
        return result['head']['status'] != '200'

    def __result_status(self, result):
        return int(result['head']['status'])

    def __result_fault(self, result):
        if ('fault' in result['head']): return result['head']['fault']
        else: return ''

    def __result_fault_code(self, result):
        if ('fault_code' in result['head']): return result['head']['fault_code']
        else: return ''

    def is_category_id(self, id):
        if (not id or len(id) == 0 or id[0] != 'c' or not id[1:].isdigit()): return False
        return True

    def is_folder_id(self, id):
        if (not id or len(id) == 0 or id[0] != 'f' or not id[1:].isdigit()): return False
        return True

    def is_genre_id(self, id):
        if (not id or len(id) == 0 or id[0] != 'g' or not id[1:].isdigit()): return False
        return True

    def is_artist_id(self, id):
        if (not id or len(id) == 0 or id[0] != 'm' or not id[1:].isdigit()): return False
        return True

    def is_region_id(self, id):
        if (not id or len(id) == 0 or id[0] != 'r' or not id[1:].isdigit()): return False
        return True

    def is_show_id(self, id):
        if (not id or len(id) == 0 or id[0] != 'p' or not id[1:].isdigit()): return False
        return True

    def is_station_id(self, id):
        if (not id or len(id) == 0 or id[0] != 's' or not id[1:].isdigit()): return False
        return True

    def is_topic_id(self, id):
        if (not id or len(id) == 0 or id[0] != 't' or not id[1:].isdigit()): return False
        return True

    def is_custom_url_id(self, id):
        if (not id or len(id) == 0 or id[0] != 'u' or not id[1:].isdigit()): return False
        return True

    def account_auth(self, username, password):
        params = [{'param': 'c', 'value': 'auth'}, {'param': 'username', 'value': username}, {'param': 'password', 'value': password}]
        result = self.__call_tunein('Account.ashx', params)
        if (self.__result_ok(result)): raise TuneIn.TuneInError(self.__result_status(result), 'Account authentication failed.')
        else: return result['body']

    def account_create(self, username, password, email, postalcode=None, city=None, countryid=None):
        params = [{'param': 'c', 'value': 'join'}, {'param': 'username', 'value': username}, {'param': 'password', 'value': password}, {'param': 'email', 'value': email}, {'param': 'postalCode', 'value': postalcode}, {'param': 'city', 'value': city}, {'param': 'countryId', 'value': countryid}]
        result = self.__call_tunein('Account.ashx', params)
        if (self.__result_ok(result)): raise TuneIn.TuneInError(self.__result_status(result), self.__result_fault(result), self.__result_fault_code(result))
        else: return result['body']

    def account_join(self, username, password):
        params = [{'param': 'c', 'value': 'join'}, {'param': 'username', 'value': username}, {'param': 'password', 'value': password}]
        result = self.__call_tunein('Account.ashx', params)
        if (self.__result_ok(result)): raise TuneIn.TuneInError(self.__result_status(result), self.__result_fault(result), self.__result_fault_code(result))
        else: return result['body']

    def account_drop(self, username, password):
        params = [{'param': 'c', 'value': 'drop'}, {'param': 'username', 'value': username}, {'param': 'password', 'value': password}]
        result = self.__call_tunein('Account.ashx', params)
        if (self.__result_ok(result)): raise TuneIn.TuneInError(self.__result_status(result), self.__result_fault(result), self.__result_fault_code(result))
        else: return result['body']

    def account_query(self):
        params = [{'param': 'c', 'value': 'query'}]
        result = self.__call_tunein('Account.ashx', params)
        if (self.__result_ok(result)): raise TuneIn.TuneInError(self.__result_status(result), self.__result_fault(result), self.__result_fault_code(result))
        else: return result['body']

    def account_remind(self, email):
        params = [{'param': 'c', 'value': 'remind'}, {'param': 'email', 'value': email}]
        result = self.__call_tunein('Account.ashx', params)
        if (self.__result_ok(result)): raise TuneIn.TuneInError(self.__result_status(result), self.__result_fault(result), self.__result_fault_code(result))
        else: return result['body']

    def account_reset(self, username=None, email=None):
        params = [{'param': 'c', 'value': 'reset'}, {'param': 'username', 'value': username}, {'param': 'email', 'value': email}]
        result = self.__call_tunein('Account.ashx', params)
        if (self.__result_ok(result)): raise TuneIn.TuneInError(self.__result_status(result), self.__result_fault(result), self.__result_fault_code(result))
        else: return result['body']

    def account_claim(self):
        params = [{'param': 'c', 'value': 'claim'}]
        result = self.__call_tunein('Account.ashx', params)
        if (self.__result_ok(result)): raise TuneIn.TuneInError(self.__result_status(result), self.__result_fault(result), self.__result_fault_code(result))
        else: return result['body']

    def browse_local(self, username=None, latlon=None, formats=None):
        params = [{'param': 'c', 'value': 'local'}, {'param': 'username', 'value': username}, {'param': 'latlon', 'value': latlon}, {'param': 'formats', 'value': formats}]
        result = self.__call_tunein('Browse.ashx', params)
        if (self.__result_ok(result)): raise TuneIn.TuneInError(self.__result_status(result), self.__result_fault(result), self.__result_fault_code(result))
        else: return result['body']

    def browse_presets(self, username=None, formats=None):
        params = [{'param': 'c', 'value': 'presets'}, {'param': 'username', 'value': username}, {'param': 'formats', 'value': formats}]
        result = self.__call_tunein('Browse.ashx', params)
        if (self.__result_ok(result)): raise TuneIn.TuneInError(self.__result_status(result), self.__result_fault(result), self.__result_fault_code(result))
        else: return result['body']

    def browse(self, channel=None, id=None, filter=None, offset=None, pivot=None, username=None):
        params = [{'param': 'c', 'value': channel}, {'param': 'id', 'value': id}, {'param': 'filter', 'value': filter}, {'param': 'offset', 'value': offset}, {'param': 'pivot', 'value': pivot}, {'param': 'username', 'value': username}]
        result = self.__call_tunein('Browse.ashx', params)
        if (self.__result_ok(result)): raise TuneIn.TuneInError(self.__result_status(result), self.__result_fault(result), self.__result_fault_code(result))
        else: return result['body']

    def browse_lang(self, filter=None):
        params = [{'param': 'c', 'value': 'lang'}, {'param': 'filter', 'value': filter}]
        result = self.__call_tunein('Browse.ashx', params)
        if (self.__result_ok(result)): raise TuneIn.TuneInError(self.__result_status(result), self.__result_fault(result), self.__result_fault_code(result))
        else: return result['body']

    def browse_station(self, id, detail=None):
        if (not self.is_station_id(id)): raise TuneIn.TuneInError(-1, 'Id is not of the correct type.')
        params = [{'param': 'id', 'value': id}, {'param': 'detail', 'value': detail}]
        result = self.__call_tunein('Browse.ashx', params)
        if (self.__result_ok(result)): raise TuneIn.TuneInError(self.__result_status(result), self.__result_fault(result), self.__result_fault_code(result))
        else: return result['body']

    def browse_schedule(self, id, username=None, start=None, stop=None, forward=None, live=None, offset=None, autodetect=None):
        if (not self.is_station_id(id)): raise TuneIn.TuneInError(-1, 'Id is not of the correct type.')
        params = [{'param': 'c', 'value': 'schedule'}, {'param': 'id', 'value': id}, {'param': 'username', 'value': username},
                  {'param': 'start', 'value': start}, {'param': 'stop', 'value': stop}, {'param': 'forward', 'value': forward},
                  {'param': 'live', 'value': live}, {'param': 'offset', 'value': offset}, {'param': 'autodetect', 'value': autodetect}]
        result = self.__call_tunein('Browse.ashx', params)
        if (self.__result_ok(result)): raise TuneIn.TuneInError(self.__result_status(result), self.__result_fault(result), self.__result_fault_code(result))
        else: return result['body']

    def browse_playlist(self, id, username=None, start=None, stop=None):
        if (not self.is_station_id(id)): raise TuneIn.TuneInError(-1, 'Id is not of the correct type.')
        params = [{'param': 'c', 'value': 'playlist'}, {'param': 'id', 'value': id}, {'param': 'username', 'value': username},
                  {'param': 'start', 'value': start}, {'param': 'stop', 'value': stop}]
        result = self.__call_tunein('Browse.ashx', params)
        if (self.__result_ok(result)): raise TuneIn.TuneInError(self.__result_status(result), self.__result_fault(result), self.__result_fault_code(result))
        else: return result['body']

    def browse_show(self, id):
        if (not self.is_show_id(id)): raise TuneIn.TuneInError(-1, 'Id is not of the correct type.')
        params = [{'param': 'id', 'value': id}]
        result = self.__call_tunein('Browse.ashx', params)
        if (self.__result_ok(result)): raise TuneIn.TuneInError(self.__result_status(result), self.__result_fault(result), self.__result_fault_code(result))
        else: return result['body']

    def config_time(self):
        params = [{'param': 'c', 'value': 'time'}]
        result = self.__call_tunein('Config.ashx', params)
        if (self.__result_ok(result)): raise TuneIn.TuneInError(self.__result_status(result), self.__result_fault(result), self.__result_fault_code(result))
        else: return result['body']

    def config_localizedstrings(self):
        params = [{'param': 'c', 'value': 'contentQuery'}]
        result = self.__call_tunein('Config.ashx', params)
        if (self.__result_ok(result)): raise TuneIn.TuneInError(self.__result_status(result), self.__result_fault(result), self.__result_fault_code(result))
        else: return result['body']

    def config_streamsample(self):
        params = [{'param': 'c', 'value': 'streamSampleQuery'}]
        result = self.__call_tunein('Config.ashx', params)
        if (self.__result_ok(result)): raise TuneIn.TuneInError(self.__result_status(result), self.__result_fault(result), self.__result_fault_code(result))
        else: return result['body']

    def describe_nowplaying(self, id):
        if (not self.is_station_id(id) and not self.is_show_id(id)): raise TuneIn.TuneInError(-1, 'Id is not of the correct type.')
        params = [{'param': 'c', 'value': 'nowplaying'}, {'param': 'id', 'value': id}]
        result = self.__call_tunein('Describe.ashx', params)
        if (self.__result_ok(result)): raise TuneIn.TuneInError(self.__result_status(result), self.__result_fault(result), self.__result_fault_code(result))
        else: return result['body']

    def describe_station(self, id, detail=None):
        if (not self.is_station_id(id)): raise TuneIn.TuneInError(-1, 'Id is not of the correct type.')
        params = [{'param': 'id', 'value': id}, {'param': 'detail', 'value': detail}]
        result = self.__call_tunein('Describe.ashx', params)
        if (self.__result_ok(result)): raise TuneIn.TuneInError(self.__result_status(result), self.__result_fault(result), self.__result_fault_code(result))
        else: return result['body']

    def describe_show(self, id, detail=None):
        if (not self.is_show_id(id)): raise TuneIn.TuneInError(-1, 'Id is not of the correct type.')
        params = [{'param': 'id', 'value': id}, {'param': 'detail', 'value': detail}]
        result = self.__call_tunein('Describe.ashx', params)
        if (self.__result_ok(result)): raise TuneIn.TuneInError(self.__result_status(result), self.__result_fault(result), self.__result_fault_code(result))
        else: return result['body']

    def describe_topic(self, id):
        if (not self.is_topic_id(id)): raise TuneIn.TuneInError(-1, 'Id is not of the correct type.')
        params = [{'param': 'id', 'value': id}]
        result = self.__call_tunein('Describe.ashx', params)
        if (self.__result_ok(result)): raise TuneIn.TuneInError(self.__result_status(result), self.__result_fault(result), self.__result_fault_code(result))
        else: return result['body']

    def describe_custom_url(self, id):
        if (not self.is_custom_url_id(id)): raise TuneIn.TuneInError(-1, 'Id is not of the correct type.')
        params = [{'param': 'id', 'value': id}]
        result = self.__call_tunein('Describe.ashx', params)
        if (self.__result_ok(result)): raise TuneIn.TuneInError(self.__result_status(result), self.__result_fault(result), self.__result_fault_code(result))
        else: return result['body']

    def describe_countries(self):
        params = [{'param': 'c', 'value': 'countries'}]
        result = self.__call_tunein('Describe.ashx', params)
        if (self.__result_ok(result)): raise TuneIn.TuneInError(self.__result_status(result), self.__result_fault(result), self.__result_fault_code(result))
        else: return result['body']

    def describe_languages(self):
        params = [{'param': 'c', 'value': 'languages'}]
        result = self.__call_tunein('Describe.ashx', params)
        if (self.__result_ok(result)): raise TuneIn.TuneInError(self.__result_status(result), self.__result_fault(result), self.__result_fault_code(result))
        else: return result['body']

    def describe_locales(self):
        params = [{'param': 'c', 'value': 'locales'}]
        result = self.__call_tunein('Describe.ashx', params)
        if (self.__result_ok(result)): raise TuneIn.TuneInError(self.__result_status(result), self.__result_fault(result), self.__result_fault_code(result))
        else: return result['body']

    def describe_formats(self):
        params = [{'param': 'c', 'value': 'formats'}]
        result = self.__call_tunein('Describe.ashx', params)
        if (self.__result_ok(result)): raise TuneIn.TuneInError(self.__result_status(result), self.__result_fault(result), self.__result_fault_code(result))
        else: return result['body']

    def describe_genres(self):
        params = [{'param': 'c', 'value': 'genres'}]
        result = self.__call_tunein('Describe.ashx', params)
        if (self.__result_ok(result)): raise TuneIn.TuneInError(self.__result_status(result), self.__result_fault(result), self.__result_fault_code(result))
        else: return result['body']

    def options(self, id):
        params = [{'param': 'id', 'value': 'id'}]
        result = self.__call_tunein('Options.ashx', params)
        if (self.__result_ok(result)): raise TuneIn.TuneInError(self.__result_status(result), self.__result_fault(result), self.__result_fault_code(result))
        else: return result['body']

    def preset_add(self, username=None, password=None, folderid=None, id=None, url=None, presetnumber=None, name=None):
        params = [{'param': 'c', 'value': 'add'}, {'param': 'username', 'value': username}, {'param': 'password', 'value': password},
                  {'param': 'folderId', 'value': folderid}, {'param': 'id', 'value': id}, {'param': 'url', 'value': url},
                  {'param': 'presetNumber', 'value': presetnumber}, {'param': 'name', 'value': name}]
        result = self.__call_tunein('Preset.ashx', params)
        if (self.__result_ok(result)): raise TuneIn.TuneInError(self.__result_status(result), self.__result_fault(result), self.__result_fault_code(result))
        else: return result['body']

    def preset_remove(self, username=None, password=None, folderid=None, id=None, url=None, presetnumber=None):
        params = [{'param': 'c', 'value': 'remove'}, {'param': 'username', 'value': username}, {'param': 'password', 'value': password},
                  {'param': 'folderId', 'value': folderid}, {'param': 'id', 'value': id}, {'param': 'url', 'value': url}, {'param': 'presetNumber', 'value': presetnumber}]
        result = self.__call_tunein('Preset.ashx', params)
        if (self.__result_ok(result)): raise TuneIn.TuneInError(self.__result_status(result), self.__result_fault(result), self.__result_fault_code(result))
        else: return result['body']

    def preset_addfolder(self, username=None, password=None, name=None):
        params = [{'param': 'c', 'value': 'addFolder'}, {'param': 'username', 'value': username}, {'param': 'password', 'value': password}, {'param': 'name', 'value': name}]
        result = self.__call_tunein('Preset.ashx', params)
        if (self.__result_ok(result)): raise TuneIn.TuneInError(self.__result_status(result), self.__result_fault(result), self.__result_fault_code(result))
        else: return result['body']

    def preset_removefolder(self, username=None, password=None, folderid=None, name=None):
        params = [{'param': 'c', 'value': 'removeFolder'}, {'param': 'username', 'value': username},
                  {'param': 'password', 'value': password}, {'param': 'folderId', 'value': folderid}]
        result = self.__call_tunein('Preset.ashx', params)
        if (self.__result_ok(result)): raise TuneIn.TuneInError(self.__result_status(result), self.__result_fault(result), self.__result_fault_code(result))
        else: return result['body']

    def preset_renamefolder(self, username=None, password=None, folderid=None, name=None):
        params = [{'param': 'c', 'value': 'renameFolder'}, {'param': 'username', 'value': username},
                  {'param': 'password', 'value': password}, {'param': 'folderId', 'value': folderid}, {'param': 'name', 'value': name}]
        result = self.__call_tunein('Preset.ashx', params)
        if (self.__result_ok(result)): raise TuneIn.TuneInError(self.__result_status(result), self.__result_fault(result), self.__result_fault_code(result))
        else: return result['body']

    def preset_listfolders(self, username=None, password=None):
        params = [{'param': 'c', 'value': 'listFolders'}, {'param': 'username','value': username}, {'param': 'password', 'value': password}]
        result = self.__call_tunein('Preset.ashx', params)
        if (self.__result_ok(result)): raise TuneIn.TuneInError(self.__result_status(result), self.__result_fault(result), self.__result_fault_code(result))
        else: return result['body']

    def recommend(self, artists, ratings=None):
        return []

    def report_wizard(self, id, email=None):
        return []

    def report_feedback(self, id, text, email=None):
        return []

    def report_stream(self, id, streamurl, error, message):
        return []

    def search(self, query, filter=None, types=None, call=None, name=None, freq=None):
        params = [{'param': 'query', 'value': query}, {'param': 'filter', 'value': filter}, {'param': 'types', 'value': types},
                  {'param': 'call', 'value': call}, {'param': 'name', 'value': name}, {'param': 'freq', 'value': freq}]
        result = self.__call_tunein('Search.ashx', params)
        if (self.__result_ok(result)): raise TuneIn.TuneInError(self.__result_status(result), self.__result_fault(result), self.__result_fault_code(result))
        else: return result['body']

    def search_artist(self, query):
        params = [{'param': 'c', 'value': 'artist'}, {'param': 'query', 'value': query}]
        result = self.__call_tunein('Search.ashx', params)
        if (self.__result_ok(result)): raise TuneIn.TuneInError(self.__result_status(result), self.__result_fault(result), self.__result_fault_code(result))
        else: return result['body']

    def search_song(self, query):
        params = [{'param': 'c', 'value': 'song'}, {'param': 'query', 'value': query}]
        result = self.__call_tunein('Search.ashx', params)
        if (self.__result_ok(result)): raise TuneIn.TuneInError(self.__result_status(result), self.__result_fault(result), self.__result_fault_code(result))
        else: return result['body']

    def search_song_artist(self, query):
        params = [{'param': 'c', 'value': 'song,artist'}, {'param': 'query', 'value': query}]
        result = self.__call_tunein('Search.ashx', params)
        if (self.__result_ok(result)): raise TuneIn.TuneInError(self.__result_status(result), self.__result_fault(result), self.__result_fault_code(result))
        else: return result['body']

    def search_stream(self, query):
        params = [{'param': 'c', 'value': 'stream'}, {'param': 'query', 'value': query}]
        result = self.__call_tunein('Search.ashx', params)
        if (self.__result_ok(result)): raise TuneIn.TuneInError(self.__result_status(result), self.__result_fault(result), self.__result_fault_code(result))
        else: return result['body']

    def tune(self, id):
        self.log_debug('tune')
        self.log_debug('id: %s' %id)
        if (not self.is_station_id(id) and not self.is_topic_id(id)): raise TuneIn.TuneInError(-1, 'Id is not of the correct type.')
        params = [{'param': 'id', 'value': id}]
        req = urllib2.Request(self.__add_params_to_url('Tune.ashx', params, addrender=False))
        f = urllib2.urlopen(req)
        self.log_debug('First pass of streams.')
        streams = []
        for stream in f:
            stream = stream.rsplit()[0]
            self.log_debug('stream: %s' %stream)
            (filepath, filename) = os.path.split(stream)
            (shortname, extension) = os.path.splitext(filename)
            filepath = filepath.lower()
            filename = filename.lower()
            shortname = shortname.lower()
            extension = extension.lower()
            self.log_debug('filepath: %s' %filepath)
            self.log_debug('filename: %s' %filename)
            self.log_debug('shortname: %s' %shortname)
            self.log_debug('extension: %s' %extension)
            if (extension == '.pls'):
                self.log_debug('PLS Playlist')
                for stream in self.__parse_pls(stream): streams.append(stream)
            elif (extension == '.asx'):
                self.log_debug('ASX Playlist')
                for stream in self.__parse_asx(stream): streams.append(stream)
            elif (extension == '.m3u'):
                self.log_debug('M3U Playlist')
                for stream in self.__parse_m3u(stream): streams.append(stream)
            elif (re.search('streamtheworld.com', filepath)):
                self.log_debug('StreamTheWorld stream')
                pattern = re.compile('(.*)callsign\=(.*)$')
                result = pattern.match(filename)
                if (result):
                    from resources.lib import streamtheworld
                    stw = streamtheworld.StreamTheWorld(result.group(2))
                    stw_url = stw.get_stream_url(result.group(2))
                    streams.append(stw_url)
            elif (stream.find('player.amri.ca') != -1):
                from resources.lib import astralradio
                self.log_debug('Astral Radio stream')
                astral = astralradio.AstralRadio(stream)
                for stream in astral.get_streams(): streams.append(stream)
            else:
                self.log_debug('Unknown stream')
                try:
                    request = urllib2.Request(stream)
                    opener = urllib2.build_opener()
                    f = opener.open(request)
                    if f.url != stream:
                        stream = f.url
                        streams.append(stream)
                    elif f.info().gettype() == 'video/x-ms-asf':
                        try:
                            for stream in self.__parse_asf(stream): streams.append(stream)
                        except:
                            try:
                                for stream in self.__parse_asx(stream): streams.append(stream)
                            except: pass
                    else: streams.append(stream)
                except urllib2.URLError as e:
                    self.log_debug('Ignoring URLError: %s' %e)
                    streams.append(stream)
        self.log_debug('Second pass of streams.')
        tmpstreams = streams
        streams = []
        for stream in tmpstreams:
            stream = stream.rsplit()[0]
            self.log_debug('stream: %s' %stream)
            (filepath, filename) = os.path.split(stream)
            (shortname, extension) = os.path.splitext(filename)
            filepath = filepath.lower()
            filename = filename.lower()
            shortname = shortname.lower()
            extension = extension.lower()
            self.log_debug('filepath: %s' %filepath)
            self.log_debug('filename: %s' %filename)
            self.log_debug('shortname: %s' %shortname)
            self.log_debug('extension: %s' %extension)
            if (extension == '.pls'):
                self.log_debug('PLS Playlist')
                for stream in self.__parse_pls(stream): streams.append(stream)
            elif (extension == '.asx'):
                self.log_debug('ASX Playlist')
                for stream in self.__parse_asx(stream): streams.append(stream)
            elif (extension == '.m3u'):
                self.log_debug('M3U Playlist')
                for stream in self.__parse_m3u(stream): streams.append(stream)
            else:
                self.log_debug('Unknown stream')
                streams.append(stream)
        return streams

    def tune_ebrowse(self, id):
        if (not self.is_station_id(id)): raise TuneIn.TuneInError(-1, 'Id is not of the correct type.')
        params = [{'param': 'id', 'value': id}, {'param': 'c', 'value': 'ebrowse'}]
        return []

    def tune_show(self, id, flatten=None, category='pbrowse', filter=''):
        if (not self.is_show_id(id)): raise TuneIn.TuneInError(-1, 'Id is not of the correct type.')
        params = [{'param': 'id', 'value': id}, {'param': 'c', 'value': category}, {'param': 'flatten', 'value': flatten}, {'param': 'filter', 'value': filter}]
        result = self.__call_tunein('Tune.ashx', params)
        if (self.__result_ok(result)): raise TuneIn.TuneInError(self.__result_status(result), self.__result_fault(result), self.__result_fault_code(result))
        return result['body']